<?php 

class m_stok extends CI_Model {
	function loaddetail($data)
	{
		$load = $this->db->query("SELECT * FROM ck_stok  WHERE 
id_produk='$idproduk' AND expired_date='$exp' AND batch_number='$batch'  AND MONTH(date_time) = '$bulan' AND YEAR(date_time)='$tahun'");
	}
	
	function populateInputBarang()
	{
		return $this->db->query("SELECT c.`id`, c.`nama`
FROM ck_produk c
WHERE c.`activated`=1");
	}
}