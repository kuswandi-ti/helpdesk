<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class stok extends CI_Controller
{
    function __construct() {
    parent::__construct(); 
    $this->load->model('m_stok'); 
    $this->load->library('pdf');
    if (isset($_SESSION['user_name']))
        $this->load->view('theme_default/setting');
    else {
        session_destroy();
        redirect(base_url() . 'login', 'location');
        }
    }
	
    function index()
    {
        $data = array(
            'title' => 'Stok Opname',
            'breadcrumb_home_active' => '',
            'breadcrumb' => '<li>Logistik</li>
                             <li>Stok</li>',
            'page_icon' => 'icon-clipboard-text',
            'page_title' => 'Minimized Open On Hover',
            'page_subtitle' => 'This option makes sublevels hoverable.',
            'custom_scripts' => '<script>$("#menu_penjualan").addClass("active");</script>'
            
            
        );
        $this->template->build('v_stok', $data);
    }
	
	function loaddetail()
	{
		$bulan = $this->input->post('bulan');
		$tahun = $this->input->post('tahun');
		$idproduk = $this->input->post('id_produk');
		$batch = $this->input->post('batch_number');
		$exp= $this->input->post('expired_date');
		$data = array(
			"bulan" => $bulan,
			"tahun" => $tahun,
			"idproduk" => $idproduk,
			"batch" => $batch,
			"exp"=>$exp
		);
$load = $this->db->query("SELECT *, p.nama FROM ck_stok  
LEFT OUTER JOIN ck_produk p on p.id = ck_stok.id_produk
WHERE 
id_produk='$idproduk'
AND MONTH(date_time) = '$bulan' AND YEAR(date_time)='$tahun'
ORDER BY batch_number, expired_date");
		if($load->num_rows() < 1)
		{
			echo '<tr>';
			echo '<td colspan=10> Tidak ada data </td>';
			echo '</tr>';
		}
		else 
		{
			$no = 1;
			foreach($load->result() as $r)
			{
				echo '<tr>';
				echo '<td>'.$no.'</td>';
				echo '<td>'.$r->date_time.'</td>';
				echo '<td>'.$r->nama.'</td>';
				echo '<td>'.$r->batch_number.'</td>';
				echo '<td>'.$r->expired_date.'</td>';
				echo '<td>'.$r->qty_awal.'</td>';
				echo '<td>'.$r->qty_masuk.'</td>';
				echo '<td>'.$r->qty_keluar.'</td>';
				echo '<td>'.$r->qty_akhir.'</td>';
				echo '<td>'.$r->status.'</td>';
				echo '</tr>';
				$no++;
			}
		}
	}
	
	function populateinputbarang()
	{
		$ret = $this->m_stok->populateInputBarang();
       header('Content-Type: application/json');
       echo json_encode($ret->result());
	}
}