<script>
$(document).ready(function(){
	
	$("#submitDetail").on('click',function(){
		var id_produk= $("#idproduk").val();
		var batch_number = $("#batchnumber").val();
		var expired_date = $("#expireddate").val();
		var tahun = $("#tahun").val();
		var bulan = $("#bulan").val();
		$.ajax({
			url:'logistik/stok/loadDetail/',
			type:'post',
			data:{
				id_produk:id_produk,
				batch_number:batch_number,
				expired_date:expired_date,
				bulan:bulan,
				tahun:tahun	
			},
			success:function(data){
				$("#showdetail").html(data);
				
			}
		});
	});
	
	$('#namaproduk').autocomplete
        ({ 
            minLength:2,
            source: function (request, response) {
                if($('#namaproduk').val()=='')
                      $("#submitDetail").prop('disabled',true);
                    var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
                    $.ajax({ 
                            url:"logistik/stok/populateinputbarang",
                            datatype:"json",
                            type:"get",
                            success:function(data)
                            {

                                    
                                    var result = response($.map(data,function(v,i)
                                    {
                                            var text = v.nama;
                                            if ( text && ( !request.term || matcher.test(text) ) ) {
                                                return {
                                                        label: v.nama,
                                                        value: v.id,
                                                        kemasan: v.kemasan,
                                                        idkemasan: v.kemasan_default,
                                                        exp_date:   v.tanggal_exp+' '+v.bulan_exp+' '+v.tahun_exp,
                                                        kadaluarsa :v.kadaluarsa,
                                                        stok:v.Stok,
                                                        namaproduk: v.nama,
                                                        hargajual: v.harga_jual,
                                                        batch: v.batch_number,
                                                        expired_date : v.expired_date
                                                        };
                                            }
                                    }))
                                    //response(results);
                            }
                    }) 
                },
                        focus: function(event, ui) {
                        // prevent autocomplete from updating the textbox
                        event.preventDefault();
                        // manually update the textbox and hidden field
                        $(this).val(ui.item.label);
                        $("#namaproduk").val(ui.item.namaproduk);
                        $("#idproduk").val(ui.item.value);
                        $("#kemasanproduk").val(ui.item.kemasan);
                        $("#idkemasanproduk").val(ui.item.idkemasan);
                        $("#expiredproduk").val(ui.item.kadaluarsa);
                        $("#expireddate").val(ui.item.expired_date);
                        $("#batchnumber").val(ui.item.batch);
                        $("#stokproduk").val(ui.item.stok);
                        $("#hargajualproduk").val(ui.item.hargajual);
                },
                        select: function(event, ui) {
                        // prevent autocomplete from updating the textbox
                        event.preventDefault();
                        // manually update the textbox and hidden field
                        $(this).val(ui.item.label);
                        $("#namaproduk").val(ui.item.namaproduk);
                        $("#idproduk").val(ui.item.value);
                        $("#kemasanproduk").val(ui.item.kemasan);
                        $("#idkemasanproduk").val(ui.item.idkemasan);
                        $("#expiredproduk").val(ui.item.kadaluarsa);
                        $("#expireddate").val(ui.item.expired_date);
                        $("#batchnumber").val(ui.item.batch);
                        $("#stokproduk").val(ui.item.stok);
                        $("#hargajualproduk").val(ui.item.hargajual);
                        $("#jumlahpesanan").focus();
                        $('#submitDetail').prop('disabled',false);
                }
        });
});
</script>

<div class="row margin-bottom-5">
	<div class="col-md-12">
		<div class="app-heading app-heading-small">
			<div class="icon icon-lg">
				<span class="icon-list3"></span>
			</div>
			<div class="title">
				<h2>Stok</h2>
				
			</div>                        
			<div class="heading-elements">
				
			</div>
		</div>                                                         
	</div>
</div>
<div class="row margin-bottom-5 ">
    <div class="col-md-12">
		<div class="block block-default">
			<div class="block-body" style="	">
				<div class='row'>
				<div class="col-md-1 ">
                    <label>Produk-Id</label>
                    <input id="idproduk" class="ui-widgets form-control  input-m" type="text" placeholder="id" readonly>
                </div>
                <div class="col-md-2 ">
                    <label>Produk</label>
                    <input id="namaproduk" class="ui-widgets form-control  input-m" type="text" placeholder="Ketik Nama Produk" autofocus="">
                </div>
                
                <div class="col-md-2 ">
                    <label>Bulan</label>
					<select id="bulan" name="bulan" class="form-control">
						<option value='1'>Januari</option>
						<option value='2'>Februari</option>
						<option value='3'>Maret</option>
						<option value='4'>April</option>
						<option value='5'>Mei</option>
						<option value='6'>Juni</option>
						<option value='7'>Juli</option>
						<option value='8'>Agustus</option>
						<option value='9'>September</option>
						<option value='10'>Oktober</option>
						<option value='11'>November</option>
						<option value='12'>Desember</option>
					</select>
                </div>
                <div class="col-md-2 ">
                    <label>Tahun</label>
                    <select id="tahun" name="tahun" class="form-control">
						<option value='2017'>2017</option>
						<option value='2018'>2018</option>
						<option value='2019'>2019</option>
					</select>
                </div>
                
                <div class="col-md-1 ">
                    <label>&nbsp;</label>
                    <input id="submitDetail" class="form-control input-m btn-info" style="background:#17b8f1; color:white;" type="submit" value="Tampilkan">
                    
                </div>
		</div>
		</div>
	</div>
	</div>
</div>

<div class="row margin-bottom-5 ">
    <div class="col-md-12">
		<div class="block block-default">
			<div class="block-body" style="	">
				<div class='row'>
					<table id="tbl" class="table table-head-custom table-striped  no-footer datatable">
					<thead>
						<tr>
							<td>No</td>
							<td>Tanggal</td>
							<td>Nama Produk</td>
							<td>Batch</td>
							<td>Expired Date</td>
							<td>Jml Awal</td>
							<td>Jml Masuk</td>
							<td>Jml Keluar</td>
							<td>Jml Akhir</td>
							<td>Status</td>
							
						</tr>
					</thead>
					<tbody id="showdetail">
					
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
