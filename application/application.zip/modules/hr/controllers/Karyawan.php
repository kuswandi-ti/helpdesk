<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Karyawan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct()
	{
		parent::__construct();
	    $this->load->database();
	    $this->load->model('KaryawanModel');
	    $this->load->model('MasterProvinsiModel');
	    $this->load->model('MasterKabupatenkotaModel');
	    $this->load->model('MasterJabatanModel');
	    $this->load->model('MasterUnitKerjaModel');
	}

	public function index()
	{
		$data["menu_left"] = VIEWPATH . "menu_left_master.php";
	    if($this->session->userdata('user_name'))
	    {
	      	$data['page_title']='Data Karyawan';
	      	$data['user_name']=$this->session->userdata('user_name');
			
	  		$data['karyawan']=$this->KaryawanModel->karyawan_list();
	  		$data['provinsi']=$this->MasterProvinsiModel->provinsi_list();
	  		$data['kabupaten_kota']=$this->MasterKabupatenkotaModel->kabupatenkota_list();
	  		$data['jabatan']=$this->MasterJabatanModel->jabatan_list();
	  		$data['unit_kerja']=$this->MasterUnitKerjaModel->unit_kerja_list();
			$data['jenis_kelamin'] = array ('P'=>'Pria', 'W', 'Wanita');
			$data['ruang'] = array ('batas_bawah'=>'1', 'batas_atas', '20');
	  		
	  		$this->load->view('header', array('data'=> $data ));
	  		$this->load->view('menu_left', array('data'=> $data ));
	  		$this->load->view('topmenu', array('data'=> $data ));
	  		$this->load->view('karyawan', array('data'=> $data ));
	  		$this->load->view('footer', array('data'=> $data ));
	    }
	    else
	    {
	      redirect(base_url().'index.php/Welcome','location');
	    }
  	}
	
  	function karyawan_view($id)
  	{	
		$data['karyawan']=$this->KaryawanModel->karyawan_view($id);
    	echo json_encode($data['karyawan'][0],true);
  	}

   function karyawan_create()
   {
    $notifikasi=$this->KaryawanModel->karyawan_create();
    if($notifikasi == 1)
    {
      $notifikasi=" Selamat ! Anda berhasil";
    }
    else
    {
      $notifikasi=" Maaf ! Anda gagal";
    }
    $notifikasi=array('notifikasi'=>$notifikasi);
    echo json_encode($notifikasi,true);
  }

  function karyawan_update()
  {
    $notifikasi=$this->KaryawanModel->karyawan_update();
    if($notifikasi == 1)
    {
      $notifikasi=" Selamat ! Anda berhasil";
    }
    else
    {
      $notifikasi=" Maaf ! Anda gagal";
    }
    $notifikasi=array('notifikasi'=>$notifikasi);
    echo json_encode($notifikasi,true);
  }

  function karyawan_delete($id = '')
  {
    $notifikasi=$this->KaryawanModel->karyawan_delete($id);
    if($notifikasi == 1)
    {
      $notifikasi=" Selamat ! Anda berhasil";
    }
    else
    {
      $notifikasi=" Maaf ! Anda gagal";
    }
    $notifikasi=array('notifikasi'=>$notifikasi);
    echo json_encode($notifikasi,true);
  }

}
