<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MasterJabatan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct()
	{
		parent::__construct();
	    $this->load->database();
	    $this->load->model('MasterKelompokKerjaModel');
	    $this->load->model('MasterUnitKerjaModel');
	    $this->load->model('MasterJabatanModel');
	}

	public function index()
	{
		$data["menu_left"] = VIEWPATH . "menu_left_master.php";
	    if($this->session->userdata('user_name'))
	    {
	      	$data['page_title']='Master Data Jabatan';
	      	$data['user_name']=$this->session->userdata('user_name');
			
			$data['jabatan_level'] = array ('1001'=>'I/a', '1002'=>'I/b', '1003'=>'I/c', '1004'=>'I/d', '2001'=>'II/a', '2002'=>'II/b', '2003'=>'II/c', '2004'=>'II/d', '3001'=>'III/a', '3002'=>'III/b', '3003'=>'III/c', '3004'=>'III/d', '4001'=>'IV/a', '4002'=>'IV/b', '4003'=>'IV/c', '4004'=>'IV/d', '5001'=>'V/a', '5002'=>'V/b', '5003'=>'V/c', '5004'=>'V/d');
	  		$data['kelompok_kerja']=$this->MasterKelompokKerjaModel->kelompok_kerja_list();
	  		$data['unit_kerja']=$this->MasterUnitKerjaModel->unit_kerja_list();
	  		$data['jabatan']=$this->MasterJabatanModel->jabatan_list();
	  		
	  		$this->load->view('header', array('data'=> $data ));
	  		$this->load->view('menu_left', array('data'=> $data ));
	  		$this->load->view('topmenu', array('data'=> $data ));
	  		$this->load->view('jabatan', array('data'=> $data ));
	  		$this->load->view('footer', array('data'=> $data ));
	    }
	    else
	    {
	      redirect(base_url().'index.php/Welcome','location');
	    }
  	}
	
  	function jabatan_view($id)
  	{	
		$data['jabatan']=$this->MasterJabatanModel->jabatan_view($id);
    	echo json_encode($data['jabatan'][0],true);
  	}

   function jabatan_create()
   {
    $notifikasi=$this->MasterJabatanModel->jabatan_create();
    if($notifikasi == 1)
    {
      $notifikasi=" Selamat ! Anda berhasil";
    }
    else
    {
      $notifikasi=" Maaf ! Anda gagal";
    }
    $notifikasi=array('notifikasi'=>$notifikasi);
    echo json_encode($notifikasi,true);
  }

  function jabatan_update()
  {
	$notifikasi=$this->MasterJabatanModel->jabatan_update();
    if($notifikasi == 1)
    {
      $notifikasi=" Selamat ! Anda berhasil";
    }
    else
    {
      $notifikasi=" Maaf ! Anda gagal";
    }
    $notifikasi=array('notifikasi'=>$notifikasi);
    echo json_encode($notifikasi,true);
  }

  function jabatan_delete($id = '')
  {
    $notifikasi=$this->MasterJabatanModel->jabatan_delete($id);
    if($notifikasi == 1)
    {
      $notifikasi=" Selamat ! Anda berhasil";
    }
    else
    {
      $notifikasi=" Maaf ! Anda gagal";
    }
    $notifikasi=array('notifikasi'=>$notifikasi);
    echo json_encode($notifikasi,true);
  }

}
