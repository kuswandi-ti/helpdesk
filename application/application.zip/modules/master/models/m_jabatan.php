<?php
class MasterJabatanModel extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    function jabatan_list()
    {
      $sql = "select * from ck_jabatan;";
      $query =$this->db->query($sql);
      return $query->result();
    }

    function jabatan_view($id)
    {
      $sql = "select * from ck_jabatan where id='".$id."';";
	  $query =$this->db->query($sql);
      return $query->result();
    }

    function jabatan_create()
    {
        $this->kode = $_POST['kode'];
        $this->nama = $_POST['nama'];
        $this->level = $_POST['level'];
        if ($_POST['kelompok']!='') $this->kelompok_kerja_id = $_POST['kelompok'];
        if ($_POST['unit']!='') $this->unit_kerja_id = $_POST['unit'];
        $this->deskripsi = $_POST['deskripsi'];
        $this->created_by = $_POST['created_by'];
        $this->created_date = date('Y-m-d H:i:s');
        $result=$this->db->insert('ck_jabatan', $this);
        return $result;
    }

    function jabatan_update()
    {
        $id=$_POST['id'];
        $this->nama = $_POST['nama'];
        $this->level = $_POST['level'];
        if ($_POST['kelompok']!='') $this->kelompok_kerja_id = $_POST['kelompok'];
        if ($_POST['unit']!='') $this->unit_kerja_id = $_POST['unit'];
        $this->deskripsi = $_POST['deskripsi'];
        $this->modified_by = $_POST['created_by'];
        $this->modified_date = date('Y-m-d H:i:s');
        $result=$this->db->update('ck_jabatan', $this, array('id' => $id));
        return $result;
    }

    function jabatan_delete($id)
    {
      $result=$this->db->delete('ck_jabatan', array('id' => $id));
      return $result;
    }
}
?>
