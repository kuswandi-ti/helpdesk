<?php
class MasterKelompokKerjaModel extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    function kelompok_kerja_list()
    {
      $sql = "select * from ck_kelompok_kerja;";
      $query =$this->db->query($sql);
      return $query->result();
    }

    function kelompok_kerja_view($id)
    {
      $sql = "select * from ck_kelompok_kerja where id='".$id."';";
	  $query =$this->db->query($sql);
      return $query->result();
    }

    function kelompok_kerja_create()
    {
        $this->nama = $_POST['nama'];
        $this->level = $_POST['level'];
        $this->deskripsi = $_POST['deskripsi'];
        $this->created_by = $_POST['created_by'];
        $this->created_date = date('Y-m-d H:i:s');
        $result=$this->db->insert('ck_kelompok_kerja', $this);
        return $result;
    }

    function kelompok_kerja_update()
    {
        $id=$_POST['id'];
        $this->nama = $_POST['nama'];
        $this->level = $_POST['level'];
        $this->deskripsi = $_POST['deskripsi'];
        $this->modified_by = $_POST['created_by'];
        $this->modified_date = date('Y-m-d H:i:s');
        $result=$this->db->update('ck_kelompok_kerja', $this, array('id' => $id));
        return $result;
    }

    function kelompok_kerja_delete($id)
    {
      $result=$this->db->delete('ck_kelompok_kerja', array('id' => $id));
      return $result;
    }
}
?>
