<?php
class MasterUnitKerjaModel extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

    function unit_kerja_list()
    {
      $sql = "select * from ck_unit_kerja order by kode;";
      $query =$this->db->query($sql);
      return $query->result();
    }

    function unit_kerja_view($id)
    {
      $sql = "select * from ck_unit_kerja where id='".$id."';";
	  $query =$this->db->query($sql);
      return $query->result();
    }

    function unit_kerja_create()
    {
        $this->kode = $_POST['kode'];
        $this->nama = $_POST['nama'];
        $this->kelompok_kerja_id = $_POST['kelompok'];
        $this->deskripsi = $_POST['deskripsi'];
        $this->created_by = $_POST['created_by'];
        $this->created_date = date('Y-m-d H:i:s');
        $result=$this->db->insert('ck_unit_kerja', $this);
        return $result;
    }

    function unit_kerja_update()
    {
        $id=$_POST['id'];
        $this->nama = $_POST['nama'];
        $this->kelompok_kerja_id = $_POST['kelompok'];
        $this->deskripsi = $_POST['deskripsi'];
        $this->modified_by = $_POST['created_by'];
        $this->modified_date = date('Y-m-d H:i:s');
        $result=$this->db->update('ck_unit_kerja', $this, array('id' => $id));
        return $result;
    }

    function unit_kerja_delete($id)
    {
      $result=$this->db->delete('ck_unit_kerja', array('id' => $id));
      return $result;
    }
}
?>
