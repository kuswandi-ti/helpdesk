<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="row">
    
    <div class="col-md-2">                                
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title"><span class="icon-printer"></span> Standar</h3>                                        
            </div>
            <div class="panel-body">                                    
                <p><strong>Laporan Keuangan Neraca Standar</strong></p>
                <p>Menampilkan laporan keuangan dalam bentuk neraca standar.</p>                                         
            </div>
            <div class="panel-footer">   
                <div class="panel-elements pull-right">
                    <button class="btn btn-primary pull-right"><span class="icon-launch"></span> Preview</button>
                </div>                                        
            </div>
        </div>
    </div>
    
</div>