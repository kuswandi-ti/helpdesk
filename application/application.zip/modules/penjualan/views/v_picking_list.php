
<div class="block block-condensed">
    <!-- START HEADING -->
    <div class="app-heading app-heading-small">
        <div class="title">
            <h5>Picking List</h5>
        </div>
    </div>
    <!-- END HEADING -->
    
    <div class="block-content" style="overflow-x:auto;">
        <table id="table_data" class="table table-head-custom table-striped  datatable no-footer font11">
            <thead> 
                <tr >
                    <th>No</th>
                    <th>No SO</th>
                    <th>Customer</th>
                    <th>SO Date</th>
                    <th>Action</th>
                </tr>
            </thead>                                    
            <tbody>
               
            </tbody>
        </table>

        </table>
    </div>
  
</div> 
<script src="assets/custom_script/pickinglist.js"></script>