
<div class="block block-condensed">
    <!-- START HEADING -->
    <div class="app-heading app-heading-small">
        <div class="title">
            <h5>List Pending Approval</h5>
        </div>
    </div>
    <!-- END HEADING -->
    
    <div class="block-content" style="">
        <table id="table_data" class="table table-head-custom table-striped  datatable no-footer font11" style="width:100%;" >
            <thead> 
                <tr class="font11">
                    <th>No</th>
                    <th>No PO</th>
                    <th>Customer</th>
                    <th>Sales</th>
                    <th>PO Date</th>
                    <th>Image</th>
                    <th>Status</th>
                    <th>History</th>
                    <th>Action</th>
                </tr>
            </thead>                                    
            <tbody>
               
            </tbody>
        </table>

        </table>
    </div>
  
</div> 
<div id="listhistori" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Histori</h4>
      </div>
      <div class="modal-body isi">
        No Data
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<script src="assets/custom_script/approval_po.js"></script>