<script>
$(document).ready(function(){

	$('#no_faktur').autocomplete
        ({ 
            minLength:2,
            source: function (request, response) {
					var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
				$.ajax({ 
						url:"penjualan/pencatatan_realisasi/populate_no_faktur",
						datatype:"json",
						type:"get",
						success:function(data)
						{
								var result = response($.map(data,function(v,i)
								{
										var text = v.no_faktur;
										if ( text && ( !request.term || matcher.test(text) ) ) {
											return {
													label: v.no_faktur,
													value: v.no_faktur,
													id: v.id,
													nama: v.nama
													};
										}
								}))
						}
					}) 
                },
					focus: function(event, ui) {
					// prevent autocomplete from updating the textbox
					event.preventDefault();
					// manually update the textbox and hidden field
					$(this).val(ui.item.label);
					$("#nama_customer").val(ui.item.nama);
					$("#id_faktur").val(ui.item.id);
                },
					select: function(event, ui) {
					// prevent autocomplete from updating the textbox
					event.preventDefault();
					// manually update the textbox and hidden field
					$(this).val(ui.item.label);
					$("#nama_customer").val(ui.item.nama);
					$("#id_faktur").val(ui.item.id);
                }
        });
	
	$("#submitDetail").on("click", function(e){
		var id = $("#id_faktur").val();
		var delivered = $("#delivered").val();
		var ket_delivered = $("#ket_delivered").val();
		var tanggal_delivered = $("#tanggal_delivered").val();
		var receiver_name = $("#receiver_name").val();
		var fdata = new FormData()
   
		if($("#file")[0].files.length>0){
			fdata.append("file",$("#file")[0].files[0]);
		
			$.ajax({
				url : 'penjualan/pencatatan_realisasi/insert_delivery',
				type: 'post',
				data: {id:id, delivered:delivered, ket_delivered:ket_delivered,tanggal_delivered:tanggal_delivered, receiver_name:receiver_name},
				
				success: function(data)
				{
					$.ajax({
						url: 'penjualan/pencatatan_realisasi/upd_img/'+id,
						type: 'POST',            
						data: fdata,
						processData: false,
						contentType: false,
						success: function (data)
						{
							alert("Done!");
							$("#id_faktur").val('');
							$("#no_faktur").val('');
							$("#delivered").val('');
							$("#ket_delivered").val('');
							$("#tanggal_delivered").val('');
							$("#receiver_name").val('');
							$("#file").val('');
							$('#table_data').DataTable().ajax.reload()
						}
					});
				}
			});
		}
		else alert("Harap Masukkan Berkas Hasil Scan!");
	});
	
	 $('#table_data').DataTable({
		"bProcessing": true,
		"bServerSide": true,
		"sServerMethod": "GET",
		"sAjaxSource": "penjualan/pencatatan_realisasi/populate",
		"iDisplayLength": 10,
		"aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
		/* "aoColumnDefs": [
           { aTargets: [ '_all' ], bSortable: false },
           { aTargets: [ 1 ], bSortable: true },
           { aTargets: [ 2 ], bSortable: true }
        ], */
		"aaSorting": [[1, 'desc']]
	});
	 
});
</script>

<div class="row margin-bottom-5">
	<div class="col-md-12">
		<div class="app-heading app-heading-small">
			<div class="icon icon-lg">
				<span class="icon-list3"></span>
			</div>
			<div class="title">
				<h2>Pencatatan Realisasi</h2>
				
			</div>                        
			<div class="heading-elements">
				
			</div>
		</div>                                                         
	</div>
</div>
<div class="row margin-bottom-5 ">
    <div class="col-md-12">
        <div class="block">
			<div class="block-body" >
			
				<div class="form-group" style="	">
					<div class="col-md-1 ">
						<label>ID</label>
						<input id="id_faktur" class="ui-widgets form-control  input-sm" type="text" placeholder="" readonly>
					</div>
					<div class="col-md-2 ">
						<label>No.</label>
						<input id="no_faktur" class="ui-widgets form-control  input-sm" type="text" autofocus placeholder="Masukkan no Faktur" >
					</div>
					<div class="col-md-2 ">
						<label>Customer</label>
						<input id="nama_customer" class="ui-widgets form-control  input-sm" type="text" placeholder="" readonly>
					</div>
					
					<div class="col-md-2 ">
						<label>Status</label>
						<select id="delivered" name="bulan" class="form-control   input-sm">
							<option value='1'>Diterima</option>
							<option value='2'>Diterima dengan catatan</option>
						</select>
					</div>
					
					<div class="col-md-2 ">
						<label>Receiver</label>
						<input id="receiver_name" class="ui-widgets form-control  input-sm" type="text" placeholder="Nama Penerima" autofocus="">
					</div>
				   
					<div class="col-md-2">
						<label>Received Date</label>
						<input id="tanggal_delivered" class="form-control bs-datepicker-weekends   input-sm"  type="text" placeholder=" " autofocus="" data-date-format="YYYY-MM-DD">
					</div>
				   
				</div>
				
				
				<div class="form-group" style="	">
					<div class="col-md-2">
						<label>Keterangan</label>
						<input class="form-control  input-sm" id="ket_delivered">
					</div>
					<div class="col-md-2">
						<label>Upload Berkas</label>
						<input type="file" class="  input-sm" id="file">
					</div>
					
					<div class="col-md-1 ">
						<label>&nbsp;</label>
						<input id="submitDetail" class="form-control input-sm btn-info" style="background:#17b8f1; color:white;" type="submit" value="Submit">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
				
<div class="row margin-bottom-5 ">
    <div class="col-md-12">
        <div class="block">
			<div class="block-body" >
			<table id="table_data" class="table table-head-custom table-striped  datatable no-footer font11">
			<thead> 
                <tr >
                    <th>No</th>
                    <th>No SO</th>
                    <th>Status</th>
                    <th>Delivered Date</th>
                    <th>Receiver</th>
                    <th>Note</th>
                    <th>Image</th>
                </tr>
            </thead>                                    
            <tbody>
               
            </tbody>
        </table>
			</div>
		</div>
	</div>
</div>