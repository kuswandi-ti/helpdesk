<?php

class m_so extends CI_Model {
	
	function populatedetail($idpo){
		return $this->db->query("SELECT h.id,h.no_so, h.bukti_gambar, h.no_po, h.no_sj,
								h.id_customer, cust.nama, cust.alamat,
								h.sales AS idsales, s.nama_sales AS sales, date_format(now(), ' %d-%m-%Y') as now,
								h.bukti_gambar, 
                                DATE_FORMAT( h.tanggal_po, '%m-%d-%Y') as tanggal_po, 
								h.created_by , h.subtotal, h.total, h.diskon_persen, 
								h.diskon_rupiah, h.ppn, h.tipe_bayar, h.jangka_waktu, h.ppn/100*(h.subtotal-h.diskon_rupiah) as ppn_rp
								FROM ck_po_customer_header h 
								LEFT OUTER JOIN ck_customer cust
								ON cust.id  = h.`id_customer`
								LEFT OUTER JOIN ck_sales s
								ON h.sales = s.id
								WHERE h.id='$idpo' ");
	}
	
	function isiDetail($idpo)
	{
		
		//////////////////////////////////////////////////////////////
		//buat nomer sj dan faktur hanya jika belum ada nomernya ////
		//////////////////////////////////////////////////////////////
		
		$getSJFAK = $this->db->query("SELECT no_faktur, no_sj FROM ck_po_customer_header where id=$idpo");
		foreach($getSJFAK->result() as $x) 
		{
			if($x->no_faktur=='') // kalau belum tercetak
			{
				///////////////////////////////////
				// buat tanggal faktur .//
				///////////////////////////////////
				
				$this->db->query("UPDATE ck_po_customer_header set tanggal_faktur = DATE(NOW()) where id='$idpo'");
				
				
				///////////////////////////////////
				//generate kode surat jalan dulu.//
				///////////////////////////////////
					$no_sj = "DN-";
					$getDate = $this->db->query("SELECT date_format(tanggal_faktur,'%d/%m/%Y') as tanggal from ck_po_customer_header where id='$idpo'");
						foreach($getDate->result() as $r):
							$no_sj.=$r->tanggal.'/';
						endforeach;
							$no_sj.=$idpo;
					$set_sj = $this->db->query("UPDATE ck_po_customer_header set no_sj = '$no_sj' where id='$idpo'");
					
				////////////////////////	
				//generate kode faktur//
				////////////////////////	
					$no_inv = "INV-";
					$getDate = $this->db->query("SELECT date_format(tanggal_faktur,'%d/%m/%Y') as tanggal from ck_po_customer_header where id='$idpo'");
						foreach($getDate->result() as $r):
							$no_inv.=$r->tanggal.'/';
						endforeach;
							$no_inv.=$idpo;
					$set_inv = $this->db->query("UPDATE ck_po_customer_header set no_faktur = '$no_inv' where id='$idpo'");
					
			}
		}
		
		return $this->db->query("SELECT pro.`nama`, kem.`nama` as kemasan,
		det.`batch_number`, DATE_FORMAT(det.`expired_date`,'%d-%m-%Y') as expired_date, det.`jumlah_pesanan`,
		det.harga_jual, det.disc_persen, det.sub_total, det.expired_date + h.jangka_waktu AS jatuh_tempo,  cust.alamat, h.no_faktur, h.tanggal_faktur, det.acc, det.keterangan
							FROM ck_po_customer_detail det
							left outer join ck_po_customer_header h
								on h.id = det.id_po
							LEFT OUTER JOIN ck_produk pro
								ON pro.id = det.`id_produk`
							LEFT OUTER JOIN ck_produk_kemasan kem
								ON kem.`id` = det.`id_kemasan`
							LEFT OUTER JOIN ck_customer cust 
								ON cust.id = h.id_customer

							where id_po='$idpo' and acc='1'");
	}
	
	function isiDetailFaktur($idpo)
	{
		
		//////////////////////////////////////////////////////////////
		//buat nomer sj dan faktur hanya jika belum ada nomernya ////
		//////////////////////////////////////////////////////////////
		
		$getSJFAK = $this->db->query("SELECT no_faktur, no_sj FROM ck_po_customer_header where id=$idpo");
		foreach($getSJFAK->result() as $x) 
		{
			if($x->no_faktur=='') // kalau belum tercetak
			{
				///////////////////////////////////
				// buat tanggal faktur .//
				///////////////////////////////////
				
				$this->db->query("UPDATE ck_po_customer_header set tanggal_faktur = DATE(NOW()) where id='$idpo'");
				
				
				///////////////////////////////////
				//generate kode surat jalan dulu.//
				///////////////////////////////////
					$no_sj = "DN-";
					$getDate = $this->db->query("SELECT date_format(tanggal_faktur,'%d/%m/%Y') as tanggal from ck_po_customer_header where id='$idpo'");
						foreach($getDate->result() as $r):
							$no_sj.=$r->tanggal.'/';
						endforeach;
							$no_sj.=$idpo;
					$set_sj = $this->db->query("UPDATE ck_po_customer_header set no_sj = '$no_sj' where id='$idpo'");
					
				////////////////////////	
				//generate kode faktur//
				////////////////////////	
					$no_inv = "INV-";
					$getDate = $this->db->query("SELECT date_format(tanggal_faktur,'%d/%m/%Y') as tanggal from ck_po_customer_header where id='$idpo'");
						foreach($getDate->result() as $r):
							$no_inv.=$r->tanggal.'/';
						endforeach;
							$no_inv.=$idpo;
					$set_inv = $this->db->query("UPDATE ck_po_customer_header set no_faktur = '$no_inv' where id='$idpo'");
					
			}
		}
		
		return $this->db->query("SELECT pro.`nama`, kem.`nama` as kemasan,
		det.`batch_number`, DATE_FORMAT(det.`expired_date`,'%d-%m-%Y') as expired_date, det.`jumlah_pesanan`,
		det.harga_jual, det.disc_persen, det.sub_total, det.expired_date + h.jangka_waktu AS jatuh_tempo,  cust.alamat, h.no_faktur, h.tanggal_faktur, det.acc, det.keterangan
							FROM ck_po_customer_detail det
							left outer join ck_po_customer_header h
								on h.id = det.id_po
							LEFT OUTER JOIN ck_produk pro
								ON pro.id = det.`id_produk`
							LEFT OUTER JOIN ck_produk_kemasan kem
								ON kem.`id` = det.`id_kemasan`
							LEFT OUTER JOIN ck_customer cust 
								ON cust.id = h.id_customer

							where id_po='$idpo'");
	}
}