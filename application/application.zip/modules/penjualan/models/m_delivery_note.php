<?php 

class m_delivery_note extends CI_Model {
	
}