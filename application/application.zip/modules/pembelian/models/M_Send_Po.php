<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_Send_Po extends CI_Model {
    
    var $tbl_po_dtl       	= 'ck_tbl_beli_po_dtl';
	
    var $view_po_hdr 		= 'ck_view_beli_po_hdr';
	var $view_produk_aktif	= 'ck_produk_aktif_view';
	
	public function __construct() {
		parent::__construct();
	}
	
	function get_header($hid) {
		$q = $this->db->query("SELECT * 
                               FROM ".$this->view_po_hdr."
							   WHERE po_id='".$hid."'
							  ");
		return $q;
	}
	
	function get_detail($hid) {
		$q = $this->db->query("SELECT a.id, a.produk_id, b.nama_produk, 
                                    b.kemasan_id, b.nama_kemasan, 
									b.nama_supplier, a.qty_po, a.harga_satuan,
									a.total, a.disc_persen, a.disc_rupiah, a.netto
							   FROM ".$this->tbl_po_dtl." a
									LEFT OUTER JOIN	".$this->view_produk_aktif." b ON a.produk_id = b.produk_id
							   WHERE a.header_id='".$hid."'
							   ORDER BY a.id");						
		return $q;
	}
	
} 