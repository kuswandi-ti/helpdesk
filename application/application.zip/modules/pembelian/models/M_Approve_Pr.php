<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_Approve_Pr extends CI_Model {
	
	var $tbl_pr_hdr     = 'ck_tbl_beli_pr_hdr';
	var $tbl_pr_dtl     = 'ck_tbl_beli_pr_dtl';
	
	var $view_pr_hdr 	= 'ck_view_beli_pr_hdr';
	var $view_pr_dtl   	= 'ck_view_beli_pr_dtl';
	
	public function __construct() {
		parent::__construct();
	}
	
	function get_header($hid) {
		$q = $this->db->query("SELECT * 
                               FROM ".$this->view_pr_hdr."
							   WHERE id='".$hid."'
							  ");
		return $q;
	}
	
	function get_detail($hid) {
		$q = $this->db->query("SELECT *
							   FROM ".$this->view_pr_dtl."
							   WHERE header_id='".$hid."'
							   ORDER BY detail_id");
		return $q;
	}
	
	function update_approve() {
		$id = $this->input->post('id');
		$status_pr = $this->input->post('status_pr');
		$status_histori = $this->input->post('status_histori');
        return $this->db->query("UPDATE ".$this->tbl_pr_hdr." 
                                 SET status_pr = '".$status_pr."',
										status_histori = CONCAT(status_histori, '".$status_histori."')
                                 WHERE id = '".$id."'");
    }
	
	function update_item_detail() {
		$id = $this->input->post('id');
		$tgl_diperlukan = date_format(new DateTime($this->input->post('tgl_diperlukan')), $this->config->item('FORMAT_DATE_TO_INSERT'));
		$qty_approve = $this->input->post('qty_approve');
        return $this->db->query("UPDATE ".$this->tbl_pr_dtl." 
                                 SET tgl_diperlukan = '".$tgl_diperlukan."', 
                                        qty_approve = '".$qty_approve."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
	
	function delete_item_detail() {
		$id = $this->input->post('id');
        return $this->db->query("DELETE FROM ".$this->tbl_pr_dtl." 
                                 WHERE id = '$id'");
    }
	
} 