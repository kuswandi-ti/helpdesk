<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_Account_Payable extends CI_Model {
	
	var $tbl_ap_hdr		= 'ck_tbl_beli_ap_hdr';
	var $tbl_ap_dtl  	= 'ck_tbl_beli_ap_dtl';
	var $tbl_gr_hdr		= 'ck_tbl_beli_gr_hdr';
	var $tbl_gr_dtl		= 'ck_tbl_beli_gr_dtl';
	var $tbl_po_hdr		= 'ck_tbl_beli_po_hdr';
	var $tbl_supplier	= 'ck_supplier';
	
	var $view_ap_hdr	= 'ck_view_beli_ap_hdr';
	var $view_ap_dtl	= 'ck_view_beli_ap_dtl';	
	
	public function __construct() {
		parent::__construct();
	}
	
	function get_supplier() {
		return $this->db->query("SELECT a.supplier_id, b.nama AS nama_supplier
								 FROM ".$this->tbl_gr_hdr." a
									 LEFT OUTER JOIN ".$this->tbl_supplier." b ON a.supplier_id = b.id
									 LEFT OUTER JOIN ".$this->tbl_gr_dtl." c ON a.id = c.header_id
								 WHERE c.id NOT IN (SELECT gr_id FROM ".$this->tbl_ap_dtl.")
								 GROUP BY a.supplier_id, b.nama
								 ORDER BY b.nama");
	}
	
	function get_gr($sid) {
		$query = "SELECT id AS gr_id, no_transaksi AS no_gr
				  FROM ".$this->tbl_gr_hdr." a
				  WHERE id NOT IN (SELECT gr_id FROM ".$this->tbl_ap_dtl.")
					  AND supplier_id = '".$sid."'
				  ORDER BY no_transaksi";
        return $this->db->query($query);
    }
	
	function create_doc_no($bulan, $tahun) {
		$q = $this->db->query("SELECT MAX(RIGHT(no_transaksi, 4)) AS no_transaksi
							   FROM ".$this->tbl_ap_hdr." 
							   WHERE  month(tgl_transaksi)='$bulan' AND year(tgl_transaksi)='$tahun'
							  ");
		$kode = '';
		if($q->num_rows() > 0) {
			foreach($q->result() as $kode) {
				$kode = ((int)$kode->no_transaksi) + 1;
				$kode = sprintf('%04s', $kode);
			}
		} else {
			$kode = '0001';
		}
		
		$pre = "AP"; // AP-YYMM-XXXX
		
		return $pre.
			   "-".
		       substr($tahun, -2).
               substr(("00".$bulan), -2).
               "-".
               $kode;
		
	}
	
	function header_create($data) {		
        $result = $this->db->insert($this->tbl_ap_hdr, $data);
		$this->session->set_userdata('hid', $this->db->insert_id());
        return $result;
	}
	
	function get_header($hid) {
		$q = $this->db->query("SELECT * 
                               FROM ".$this->view_ap_hdr."
							   WHERE id='".$hid."'
							  ");
		return $q;
	}
	
	function get_detail($hid) {
		$q = $this->db->query("SELECT *
							   FROM ".$this->view_ap_dtl." 
							   WHERE header_id = '".$hid."'	
						       ORDER BY detail_id");								
		return $q;
	}
	
	function get_gr_add($sid) {
		$q = $this->db->query("SELECT a.id AS gr_id, a.no_transaksi AS no_gr,
								  a.tgl_transaksi AS tgl_gr, a.no_sj_supplier,
								  a.tgl_terima, a.po_id, b.no_transaksi AS no_po,
								  b.tgl_transaksi AS tgl_po
							  FROM ".$this->tbl_gr_hdr." a
								  LEFT OUTER JOIN ".$this->tbl_po_hdr." b ON a.po_id = b.id
							  WHERE a.id NOT IN (SELECT gr_id FROM ".$this->tbl_ap_dtl.")
								  AND a.supplier_id = '".$sid."'	
							  ORDER BY a.no_transaksi	");								
		return $q;
	}
	
	function detail_create($data) {        
		$result = $this->db->insert($this->tbl_ap_dtl, $data);
		return $result;
	}
    
    function detail_list($hid) {
		return $this->db->query("SELECT *
							     FROM ".$this->view_ap_dtl." 
							     WHERE header_id = '".$hid."'	
						         ORDER BY detail_id");
    }
	
	function update_header() {
		$id = $this->input->post('id');
		$keterangan = $this->input->post('keterangan');
        return $this->db->query("UPDATE ".$this->tbl_ap_hdr." 
                                 SET keterangan = '".$keterangan."'
                                 WHERE id = '".$id."'");
    }
	
} 