<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_Validasi_Tagihan extends CI_Model {
	
	var $table_penerimaantagihan_header  		= 'ck_penerimaantagihan_header';
	var $table_penerimaantagihan_detail  		= 'ck_penerimaantagihan_detail';
	var $view_penerimaantagihan_header			= 'ck_penerimaantagihan_header_view';
	var $view_penerimaantagihan_detail			= 'ck_penerimaantagihan_detail_view';
	
	public function __construct() {
		parent::__construct();
	}
	
	function get_header($hid) {
		$q = $this->db->query("SELECT * 
                               FROM ".$this->view_penerimaantagihan_header."
							   WHERE id='".$hid."'
							  ");
		return $q;
	}
	
	function get_detail($hid) {
		$q = $this->db->query("SELECT *
							   FROM ".$this->view_penerimaantagihan_detail." 
							   WHERE header_id = '".$hid."'	
						       ORDER BY detail_id");								
		return $q;
	}
    
    function detail_list($hid) {
		return $this->db->query("SELECT *
							     FROM ".$this->view_penerimaantagihan_detail." 
							     WHERE header_id = '".$hid."'	
						         ORDER BY detail_id");
    }
	
	function update_header() {
		$id = $this->input->post('id');
        return $this->db->query("UPDATE ".$this->table_penerimaantagihan_header." 
                                 SET validasi = '1',
                                        validasi_by = '".$this->session->userdata('user_name')."',
                                        validasi_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
	
} 