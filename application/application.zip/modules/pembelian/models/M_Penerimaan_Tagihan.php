<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_Penerimaan_Tagihan extends CI_Model {
	
	var $table_penerimaantagihan_header  		= 'ck_penerimaantagihan_header';
	var $table_penerimaantagihan_detail  		= 'ck_penerimaantagihan_detail';
	var $view_penerimaantagihan_header			= 'ck_penerimaantagihan_header_view';
	var $view_penerimaantagihan_detail			= 'ck_penerimaantagihan_detail_view';
	var $table_pemesananpembelian_detail		= 'ck_pemesananpembelian_detail';
	var $table_po_header                		= 'ck_pemesananpembelian_header';
	var $table_supplier                 		= 'ck_supplier';
	var $table_produk                   		= 'ck_produk';
	var $table_produk_kemasan           		= 'ck_produk_kemasan';
	var $view_os_pt_2							= 'ck_os_qty_gr_vs_pt_2_view';
	var $view_os_pt_3							= 'ck_os_qty_gr_vs_pt_3_view';
	
	public function __construct() {
		parent::__construct();
	}
	
	function get_supplier() {
		return $this->db->query("SELECT supplier_id, nama_supplier
								 FROM ".$this->view_os_pt_2."
								 WHERE os_pt > 0
								 GROUP BY supplier_id, nama_supplier
								 ORDER BY nama_supplier");
	}
	
	function get_gr($sid) {
		$query = "SELECT gr_id, no_gr
				  FROM ".$this->view_os_pt_2."
				  WHERE supplier_id = '".$sid."' 
					  AND os_pt > 0
				  GROUP BY gr_id, no_gr
				  ORDER BY no_gr";
        return $this->db->query($query);
    }
	
	function create_doc_no($bulan, $tahun) {
		$q = $this->db->query("SELECT MAX(RIGHT(no_transaksi, 4)) AS no_transaksi
							   FROM ".$this->table_penerimaantagihan_header." 
							   WHERE  month(tgl_transaksi)='$bulan' AND year(tgl_transaksi)='$tahun'
							  ");
		$kode = '';
		if($q->num_rows() > 0) {
			foreach($q->result() as $kode) {
				$kode = ((int)$kode->no_transaksi) + 1;
				$kode = sprintf('%04s', $kode);
			}
		} else {
			$kode = '0001';
		}
		
		$pre = "PT"; // PT-YYMM-XXXX
		
		return $pre.
			   "-".
		       substr($tahun, -2).
               substr(("00".$bulan), -2).
               "-".
               $kode;
		
	}
	
	function header_create($data) {		
        $result = $this->db->insert($this->table_penerimaantagihan_header, $data);
		$this->session->set_userdata('hid', $this->db->insert_id());
        return $result;
	}
	
	function get_header($hid) {
		$q = $this->db->query("SELECT * 
                               FROM ".$this->view_penerimaantagihan_header."
							   WHERE id='".$hid."'
							  ");
		return $q;
	}
	
	function get_detail($hid) {
		$q = $this->db->query("SELECT *
							   FROM ".$this->view_penerimaantagihan_detail." 
							   WHERE header_id = '".$hid."'	
						       ORDER BY detail_id");								
		return $q;
	}
	
	function detail_create($data) {        
		$result = $this->db->insert($this->table_penerimaantagihan_detail, $data);
		return $result;
	}
	
	function produk_per_po($po_id) {
        return $this->db->query("SELECT a.produk_id, CONCAT_WS(' - ', b.nama, c.nama, d.nama) AS nama_produk
								 FROM ".$this->table_pemesananpembelian_detail." a
									LEFT OUTER JOIN ".$this->table_produk." b ON a.produk_id = b.id
									LEFT OUTER JOIN ".$this->table_produk_kemasan." c ON b.kemasan_default = c.id
									LEFT OUTER JOIN ".$this->table_supplier." d ON b.supplier_id = d.id
								 WHERE a.header_id = '".$po_id."'");		
    }
    
    function detail_list($hid) {
		return $this->db->query("SELECT *
							     FROM ".$this->view_penerimaantagihan_detail." 
							     WHERE header_id = '".$hid."'	
						         ORDER BY detail_id");
    }
    
    function delete_item_detail($id) {		
        return $this->db->query("DELETE FROM ".$this->table_penerimaantagihan_detail." WHERE id='$id'");
    }
    
    function update_item_detail() {
		$id 				= $this->input->post('id');
		//$gr_id 			= $this->input->post('gr_id');
		$produk_id 			= $this->input->post('produk_id');
		//$batch_number 	= $this->input->post('batch_number');
		//$expired_date 	= date_format(new DateTime($this->input->post('expired_date')), $this->config->item('FORMAT_DATE_TO_INSERT'));
		$jumlah 			= $this->input->post('jumlah');
		$harga_satuan 		= $this->input->post('harga_satuan');			
		$total 				= $this->input->post('total');
		$disc_persen 		= $this->input->post('disc_persen');
		$disc_rupiah 		= $this->input->post('disc_rupiah');
		$netto 				= $this->input->post('netto');
        /*return $this->db->query("UPDATE ".$this->table_penerimaantagihan_detail." 
                                 SET batch_number = '".$batch_number."', 
                                        expired_date = '".$expired_date."',
										jumlah = '".$jumlah."',
										harga_satuan = '".$harga_satuan."',
										total = '".$total."',
										disc_persen = '".$disc_persen."',
										disc_rupiah = '".$disc_rupiah."',
										netto = '".$netto."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");*/
		return $this->db->query("UPDATE ".$this->table_penerimaantagihan_detail." 
                                 SET jumlah = '".$jumlah."',
										harga_satuan = '".$harga_satuan."',
										total = '".$total."',
										disc_persen = '".$disc_persen."',
										disc_rupiah = '".$disc_rupiah."',
										netto = '".$netto."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
	
	function update_header() {
		$id = $this->input->post('id');
		$no_faktur_supplier = $this->input->post('no_faktur_supplier');
		$tgl_faktur_supplier = date_format(new DateTime($this->input->post('tgl_faktur_supplier')), $this->config->item('FORMAT_DATE_TO_INSERT'));
		$tgl_jatuh_tempo = date_format(new DateTime($this->input->post('tgl_jatuh_tempo')), $this->config->item('FORMAT_DATE_TO_INSERT'));
		$keterangan = $this->input->post('keterangan');
		$total_barang = $this->input->post('total_barang');
		$disc_persen = $this->input->post('disc_persen');
		$disc_rupiah = $this->input->post('disc_rupiah');
		$dpp = $this->input->post('dpp');
		$ppn_persen = $this->input->post('ppn_persen');
		$ppn_rupiah = $this->input->post('ppn_rupiah');
		$materai = $this->input->post('materai');
		$grand_total = $this->input->post('grand_total');
        return $this->db->query("UPDATE ".$this->table_penerimaantagihan_header." 
                                 SET no_faktur_supplier = '".$no_faktur_supplier."',
										tgl_faktur_supplier = '".$tgl_faktur_supplier."',
										tgl_jatuh_tempo = '".$tgl_jatuh_tempo."',
										keterangan = '".$keterangan."',
										total_barang = '".$total_barang."',
										disc_persen = '".$disc_persen."',
										disc_rupiah = '".$disc_rupiah."',
										dpp = '".$dpp."',
										ppn_persen = '".$ppn_persen."',
										ppn_rupiah = '".$ppn_rupiah."',
										materai = '".$materai."',
										grand_total = '".$grand_total."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
    
    function get_total_barang_detail($header_id, $disc_persen = 0, $disc_rp = 0, $ppn_persen = 0, $materai = 0) {
        $total_barang = $this->db->query("SELECT SUM(netto) AS total_barang
                                          FROM ".$this->table_penerimaantagihan_detail."
                                          WHERE header_id = '".$header_id."'")->row()->total_barang;
        if ($disc_persen > 0) {
            $disc_rp_result = ($disc_persen / 100) * $total_barang;
        } else {
            $disc_persen = 0;
            $disc_rp_result = $disc_persen;
        }
        $dpp_result = $total_barang - $disc_rp_result;
        if ($ppn_persen > 0) {
            $ppn_rp_result = ($ppn_persen / 100) * $dpp_result;
        } else {
            $ppn_rp_result = 0;
        }
        $grand_total = $dpp_result + $ppn_rp_result + $materai;
        
        // Update header
        $this->db->query("UPDATE ".$this->table_penerimaantagihan_header." 
                          SET total_barang = '".$total_barang."',
                                disc_persen = '".$disc_persen."',
                                disc_rupiah = '".$disc_rp_result."',
                                dpp = '".$dpp_result."',
                                ppn_persen = '".$ppn_persen."',
                                ppn_rupiah = '".$ppn_rp_result."',
                                materai = '".$materai."',
                                grand_total = '".$grand_total."'
                          WHERE id = '".$header_id."'");
        
        // Output ke controller
        return $this->db->query("SELECT *
                                 FROM ".$this->table_penerimaantagihan_header."
                                 WHERE id = '".$header_id."'");
        
    }
	
	function get_data_gr() {
		$hid = $this->input->post('hid');
		$gr_id = $this->input->post('gr_id');		
		$this->db->query("DELETE FROM ".$this->table_penerimaantagihan_detail."
						  WHERE header_id = '".$hid."'");
		return $this->db->query("INSERT INTO ".$this->table_penerimaantagihan_detail." (header_id, produk_id, 
									 batch_number, expired_date, jumlah, harga_satuan,
									 total, disc_persen, disc_rupiah, netto, created_by, created_date, 
									 modified_by, modified_date) 
								 SELECT '".$hid."', produk_id, batch_number, expired_date, os_pt,
									harga_satuan, total, disc_persen, disc_rupiah, netto,
									'".$this->session->userdata('user_name')."', '".date('Y-m-d H:i:s')."', 
									'".$this->session->userdata('user_name')."', '".date('Y-m-d H:i:s')."'
							     FROM ".$this->view_os_pt_3."
								 WHERE gr_id = '".$gr_id."'  
									AND os_pt > 0");
	}
	
} 