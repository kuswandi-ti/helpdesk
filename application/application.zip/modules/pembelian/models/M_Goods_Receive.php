<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_Goods_Receive extends CI_Model {
	
	var $tbl_gr_hdr  		= 'ck_tbl_beli_gr_hdr';
	var $tbl_gr_dtl  		= 'ck_tbl_beli_gr_dtl';
	var $tbl_po_dtl			= 'ck_tbl_beli_po_dtl';
	var $tbl_po_hdr   		= 'ck_tbl_beli_po_hdr';	
	var $tbl_supplier    	= 'ck_supplier';
	var $tbl_produk       	= 'ck_produk';
	var $tbl_produk_kemasan	= 'ck_produk_kemasan';
	
	var $view_gr_hdr		= 'ck_view_beli_gr_hdr';
	var $view_gr_dtl		= 'ck_view_beli_gr_dtl';	
	var $view_os_po			= 'ck_view_beli_os_qty_po_vs_gr_2';
	
	public function __construct() {
		parent::__construct();
	}
	
	function get_supplier() {
		return $this->db->query("SELECT supplier_id, nama_supplier 
		                         FROM ".$this->view_os_po."
								 WHERE qty_os_gr > 0
								 GROUP BY supplier_id, nama_supplier
								 ORDER BY nama_supplier");
	}
	
	function create_doc_no($bulan, $tahun) {
		$q = $this->db->query("SELECT MAX(RIGHT(no_transaksi, 4)) AS no_transaksi
							   FROM ".$this->tbl_gr_hdr." 
							   WHERE  month(tgl_transaksi)='$bulan' AND year(tgl_transaksi)='$tahun'
							  ");
		$kode = '';
		if($q->num_rows() > 0) {
			foreach($q->result() as $kode) {
				$kode = ((int)$kode->no_transaksi) + 1;
				$kode = sprintf('%04s', $kode);
			}
		} else {
			$kode = '0001';
		}
		
		$pre = "GR"; // GR-YYMM-XXXX
		
		return $pre.
			   "-".
		       substr($tahun, -2).
               substr(("00".$bulan), -2).
               "-".
               $kode;
		
	}
	
	function header_create($data) {		
        $result = $this->db->insert($this->tbl_gr_hdr, $data);
		$this->session->set_userdata('hid', $this->db->insert_id());
        return $result;
	}
	
	function get_header($hid) {
		$q = $this->db->query("SELECT * 
                               FROM ".$this->view_gr_hdr."
							   WHERE id='".$hid."'
							  ");
		return $q;
	}
	
	function get_detail($hid) {
		$q = $this->db->query("SELECT *
							   FROM ".$this->view_gr_dtl." 
							   WHERE header_id = '".$hid."'	
						       ORDER BY id");								
		return $q;
	}
	
	function detail_create($data) {        
		$result = $this->db->insert($this->tbl_gr_dtl, $data);
		return $result;
	}
	
	function get_po($sid) {
        $query = "SELECT po_id, no_po 
					 FROM ".$this->view_os_po."
				  WHERE supplier_id = '".$sid."' 
					 AND qty_os_gr > 0
				  GROUP BY po_id, no_po
				  ORDER BY no_po";
        return $this->db->query($query);
    }
    
    function detail_list($hid) {
		return $this->db->query("SELECT *
							     FROM ".$this->view_gr_dtl." 
							     WHERE header_id = '".$hid."'	
						         ORDER BY id");
    }
    
    function delete_item_detail() {
		$id = $this->input->post('id');
		$po_id = $this->input->post('po_id');
		$produk_id = $this->input->post('produk_id');
		$qty_gr = $this->input->post('qty_gr');
        return $this->db->query("DELETE FROM ".$this->tbl_gr_dtl." WHERE id='$id'");
    }
    
    function update_item_detail() {
		$id = $this->input->post('id');
		$po_id = $this->input->post('po_id');
		$produk_id = $this->input->post('produk_id');
		$batch_number = $this->input->post('batch_number');
		$expired_date = date_format(new DateTime($this->input->post('expired_date')), $this->config->item('FORMAT_DATE_TO_INSERT'));
		$qty_gr = $this->input->post('qty_gr');
		$qty_gr_hidden = $this->input->post('qty_gr_hidden');
        return $this->db->query("UPDATE ".$this->tbl_gr_dtl." 
                                 SET batch_number = '".$batch_number."', 
                                        expired_date = '".$expired_date."',
										qty_gr = '".$qty_gr."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
	
	function update_header() {
		$id = $this->input->post('id');
		$no_sj_supplier = $this->input->post('no_sj_supplier');
		$tgl_terima = $this->input->post('tgl_terima');
		$keterangan = $this->input->post('keterangan');
        return $this->db->query("UPDATE ".$this->tbl_gr_hdr." 
                                 SET no_sj_supplier ='".$no_sj_supplier."',
										tgl_terima = '".date_format(new DateTime($tgl_terima), $this->config->item('FORMAT_DATE_TO_INSERT'))."',
										keterangan = '".$keterangan."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
	
	function get_data_po() {
		$hid = $this->input->post('header_id');
		$po_id = $this->input->post('po_id');
		
		//$this->db->query("DELETE FROM ".$this->tbl_gr_dtl." WHERE header_id = '".$hid."'");		
		return $this->db->query("INSERT INTO ".$this->tbl_gr_dtl." (header_id, produk_id, 
									 batch_number, expired_date, qty_gr, created_by, created_date, 
									 modified_by, modified_date) 
								 SELECT '".$hid."', produk_id, '', '".date('Y-m-d H:i:s')."', qty_os_gr, 
									 '".$this->session->userdata('user_name')."', '".date('Y-m-d H:i:s')."', 
									 '".$this->session->userdata('user_name')."', '".date('Y-m-d H:i:s')."'
								 FROM ".$this->view_os_po."
								 WHERE po_id = '".$po_id."'
									 AND qty_os_gr > 0 
									 AND status_po = '3'");
	}
	
} 