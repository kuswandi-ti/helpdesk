<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_Pembayaran_Pembelian extends CI_Model {
	
	var $table_pembayaranpembelian_header  		= 'ck_pembayaranpembelian_header';
	var $table_pembayaranpembelian_detail  		= 'ck_pembayaranpembelian_detail';
	var $view_pembayaranpembelian_header		= 'ck_pembayaranpembelian_header_view';
	var $view_pembayaranpembelian_detail		= 'ck_pembayaranpembelian_detail_view';
	var $table_penerimaantagihan_header			= 'ck_penerimaantagihan_header';
	var $view_os_pp_2							= 'ck_os_rp_pt_vs_pp_2_view';
	
	public function __construct() {
		parent::__construct();
	}
	
	function get_info_invoice() {
		$no_invoice_supplier = $this->input->post('no_invoice_supplier');
		$os_pp = $this->db->query("SELECT os_pp 
		                           FROM ".$this->view_os_pp_2."
								   WHERE no_invoice_supplier = '".$no_invoice_supplier."'")->row()->os_pp;
		return $os_pp;
	}
	
	function get_supplier() {
		return $this->db->query("SELECT supplier_id, nama_supplier
								 FROM ".$this->view_os_pp_2."
								 WHERE os_pp > 0
								 GROUP BY supplier_id, nama_supplier
								 ORDER BY nama_supplier");
	}
	
	function get_invoice() {
		return $this->db->query("SELECT no_invoice_supplier
								 FROM ".$this->view_os_pp_2."
								 WHERE os_pp > 0
								 GROUP BY no_invoice_supplier
								 ORDER BY no_invoice_supplier");
	}
	
	function create_doc_no($bulan, $tahun) {
		$q = $this->db->query("SELECT MAX(RIGHT(no_transaksi, 4)) AS no_transaksi
							   FROM ".$this->table_pembayaranpembelian_header." 
							   WHERE  month(tgl_transaksi)='$bulan' AND year(tgl_transaksi)='$tahun'
							  ");
		$kode = '';
		if($q->num_rows() > 0) {
			foreach($q->result() as $kode) {
				$kode = ((int)$kode->no_transaksi) + 1;
				$kode = sprintf('%04s', $kode);
			}
		} else {
			$kode = '0001';
		}
		
		$pre = "BB"; // PP-YYMM-XXXX
		
		return $pre.
			   "-".
		       substr($tahun, -2).
               substr(("00".$bulan), -2).
               "-".
               $kode;
		
	}
	
	function header_create($data) {		
        $result = $this->db->insert($this->table_pembayaranpembelian_header, $data);
		$this->session->set_userdata('hid', $this->db->insert_id());
        return $result;
	}
	
	function get_header($hid) {
		$q = $this->db->query("SELECT * 
                               FROM ".$this->view_pembayaranpembelian_header."
							   WHERE id='".$hid."'
							  ");
		return $q;
	}
	
	function get_detail($hid) {
		$q = $this->db->query("SELECT *
							   FROM ".$this->view_pembayaranpembelian_detail." 
							   WHERE header_id = '".$hid."'	
						       ORDER BY id");								
		return $q;
	}
	
	function detail_create($data) {        
		$result = $this->db->insert($this->table_pembayaranpembelian_detail, $data);
		return $result;
	}
    
    function detail_list($hid) {
		return $this->db->query("SELECT *
							     FROM ".$this->view_pembayaranpembelian_detail." 
							     WHERE header_id = '".$hid."'	
						         ORDER BY id");
    }
    
    function delete_item_detail($id) {		
        return $this->db->query("DELETE FROM ".$this->table_pembayaranpembelian_detail." WHERE id='$id'");
    }
    
    function update_item_detail() {
		$id 				= $this->input->post('id');
		$disc_persen 		= $this->input->post('discpersen_edit');
		$disc_rupiah 		= $this->input->post('discrupiah_edit');
		$netto_dibayar 		= $this->input->post('dibayar_edit');	
		return $this->db->query("UPDATE ".$this->table_pembayaranpembelian_detail." 
                                 SET disc_persen = '".$disc_persen."',
										disc_rupiah = '".$disc_rupiah."',
										netto_dibayar = '".$netto_dibayar."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
	
	function update_header() {
		$id = $this->input->post('id');
		$keterangan = $this->input->post('keterangan');
		$total_invoice = $this->input->post('total_invoice');
		$disc_persen = $this->input->post('disc_persen');
		$disc_rupiah = $this->input->post('disc_rupiah');
		$dpp = $this->input->post('dpp');
		$ppn_persen = $this->input->post('ppn_persen');
		$ppn_rupiah = $this->input->post('ppn_rupiah');
		$materai = $this->input->post('materai');
		$grand_total = $this->input->post('grand_total');
        return $this->db->query("UPDATE ".$this->table_pembayaranpembelian_header." 
                                 SET keterangan = '".$keterangan."',
										total_invoice = '".$total_invoice."',
										disc_persen = '".$disc_persen."',
										disc_rupiah = '".$disc_rupiah."',
										dpp = '".$dpp."',
										ppn_persen = '".$ppn_persen."',
										ppn_rupiah = '".$ppn_rupiah."',
										materai = '".$materai."',
										grand_total = '".$grand_total."',
                                        modified_by = '".$this->session->userdata('user_name')."',
                                        modified_date = '".date('Y-m-d H:i:s')."'
                                 WHERE id = '".$id."'");
    }
    
    function get_total_barang_detail($header_id, $disc_persen = 0, $disc_rp = 0, $ppn_persen = 0, $materai = 0) {
        $total_barang = $this->db->query("SELECT SUM(netto_dibayar) AS total_barang
                                          FROM ".$this->table_pembayaranpembelian_detail."
                                          WHERE header_id = '".$header_id."'")->row()->total_barang;
        if ($disc_persen > 0) {
            $disc_rp_result = ($disc_persen / 100) * $total_barang;
        } else {
            $disc_persen = 0;
            $disc_rp_result = $disc_persen;
        }
        $dpp_result = $total_barang - $disc_rp_result;
        if ($ppn_persen > 0) {
            $ppn_rp_result = ($ppn_persen / 100) * $dpp_result;
        } else {
            $ppn_rp_result = 0;
        }
        $grand_total = $dpp_result + $ppn_rp_result + $materai;
        
        // Update header
        $this->db->query("UPDATE ".$this->table_pembayaranpembelian_header." 
                          SET total_invoice = '".$total_barang."',
                                disc_persen = '".$disc_persen."',
                                disc_rupiah = '".$disc_rp_result."',
                                dpp = '".$dpp_result."',
                                ppn_persen = '".$ppn_persen."',
                                ppn_rupiah = '".$ppn_rp_result."',
                                materai = '".$materai."',
                                grand_total = '".$grand_total."'
                          WHERE id = '".$header_id."'");
        
        // Output ke controller
        return $this->db->query("SELECT *
                                 FROM ".$this->table_pembayaranpembelian_header."
                                 WHERE id = '".$header_id."'");
        
    }
	
} 