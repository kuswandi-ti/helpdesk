<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
    
    $id_transaksi = '';
    $no_transaksi = ''; 
	$tgl_transaksi = ''; 
    $supplier_id = '';
	$nama_supplier = '';
	$gr_id = '';
	$no_gr = '';
	$no_invoice_supplier = '';
	$tgl_invoice_supplier = '';
	$tgl_jatuh_tempo = '';
	$keterangan = '';
	$no_po = '';
	$total_barang = '0';
	$disc_persen = '0';
	$disc_rp = '0';
	$dpp = '0';
	$ppn_persen = '0';
	$ppn_rp = '0';
	$materai = '0';
	$grand_total = '0';
	$validasi = '';

    if ($get_header->num_rows() > 0) {
        foreach($get_header->result() as $row) {
			$id_transaksi = $row->id;
			$no_transaksi = $row->no_transaksi; 
			$tgl_transaksi = $row->tgl_transaksi; 
			$supplier_id = $row->supplier_id;
			$nama_supplier = $row->nama_supplier;
			$gr_id = $row->gr_id;
			$no_gr = $row->no_gr;
			$no_invoice_supplier = $row->no_invoice_supplier;
			$tgl_invoice_supplier = $row->tgl_invoice_supplier;
			$tgl_jatuh_tempo = $row->tgl_jatuh_tempo;
			$keterangan = $row->keterangan;
			$no_po = $row->no_po;
			$total_barang = $row->total_barang;
			$disc_persen = $row->disc_persen;
			$disc_rp = $row->disc_rupiah;
			$dpp = $row->dpp;
			$ppn_persen = $row->ppn_persen;
			$ppn_rp = $row->ppn_rupiah;
			$materai = $row->materai;
			$grand_total = $row->grand_total;
			$validasi = $row->validasi;
        } 
    }
?>

<!-- Begin : Block Header -->
<div class="block">
    <div class="row">
        <div class="col-md-2">
            <label>No. Transaksi</label>
            <div class="input-group">
                <input id="txtnotransaksi_hdr" name="txtnotransaksi_hdr" type="text" class="form-control input-sm" value="<?php echo $no_transaksi; ?>" readonly>
                <input id="txtidtransaksi_hdr" name="txtidtransaksi_hdr" type="hidden" class="form-control" value="<?php echo $id_transaksi; ?>" readonly>
            </div>
        </div>
        <div class="col-md-2">
            <label>Tgl. Transaksi</label>
            <div class="input-group">
                <input id="txttgltransaksi_hdr" name="txttgltransaksi_hdr" type="text" class="form-control input-sm" value="<?php echo date_format(new DateTime($tgl_transaksi), $this->config->item('FORMAT_DATE_TO_DISPLAY')); ?>" readonly>
            </div>
        </div>        
        <div class="col-md-6">
            <label>Supplier</label>
            <div class="input-group">
                <input id="txtnamasupplier_hdr" name="txtnamasupplier_hdr" type="text" class="form-control input-sm" value="<?php echo $nama_supplier; ?>" readonly>
				<input id="txtsupplierid_hdr" name="txtsupplierid_hdr" type="hidden" class="form-control input-sm" value="<?php echo $supplier_id; ?>" readonly>
            </div>
        </div>
		<div class="col-md-2">
            <label>No. GR</label>
            <div class="input-group">
                <input id="txtnogr_hdr" name="txtnogr_hdr" type="text" class="form-control input-sm" value="<?php echo $no_gr; ?>" readonly>
				<input id="txtgrid_hdr" name="txtgrid_hdr" type="hidden" class="form-control input-sm" value="<?php echo $gr_id; ?>" readonly>
            </div>
        </div>
    </div>

    <div class="row">
		<div class="col-md-4">
			<div class="row">
				<div class="col-md-6">
					<label>No. Invoice Supplier</label>
					<div class="input-group group-noinvoicesupplier-hdr">
						<input id="txtnoinvoicesupplier_hdr" name="txtnoinvoicesupplier_hdr" type="text" class="form-control input-sm" value="<?php echo $no_invoice_supplier; ?>">
					</div>
				</div>
				<div class="col-md-6">
					<label>Tgl. Jatuh Tempo</label>
					<div class="input-group group-tgljatuhtempo-hdr">
						<input id="txttgljatuhtempo_hdr" name="txttgljatuhtempo_hdr" type="text" class="form-control input-sm" value="<?php echo date_format(new DateTime($tgl_jatuh_tempo), $this->config->item('FORMAT_DATE_TO_DISPLAY')); ?>">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<label>Tgl. Invoice Supplier</label>
					<div class="input-group group-tglinvoicesupplier-hdr">
						<input id="txttglinvoicesupplier_hdr" name="txttglinvoicesupplier_hdr" type="text" class="form-control input-sm" value="<?php echo date_format(new DateTime($tgl_invoice_supplier), $this->config->item('FORMAT_DATE_TO_DISPLAY')); ?>">
					</div>
				</div>
				<div class="col-md-6">
					<label>No. PO</label>
					<div class="input-group">
						<input id="txtnopo_hdr" name="txtnopo_hdr" type="text" class="form-control input-sm" value="<?php echo $no_po; ?>" readonly>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-8">
			<label>Keterangan</label>
            <div class="input-group">
                <textarea id="txtketerangan_hdr" name="txtketerangan_hdr" class="form-control" rows="4"><?php echo $keterangan; ?></textarea>
            </div>
		</div>
    </div>
</div>
<!-- End : Block Header -->

<!-- Begin : Block Detail -->
<div class="block">
	<?php
		if ($validasi == '0') {
	?>
	<div class="row">
		<div class="col-md-2 pull-right">
			<label>&nbsp;</label>
			<div class="input-group">
				<button id="get_data" type="submit" class="btn btn-warning btn-icon-fixed pull-right"><span class="icon-plus"></span> Data Dari GR</button>
			</div>
		</div>
	</div>
	<?php
		}
	?>
	
    <div class="row">
        <div class="col-md-12">            
            <table id="table_detail" class="table table-head-custom table-striped" style="width: 100%;">
                <thead>
                    <tr>
                        <th style="display: none">ID</th>
                        <th style="width: 4%; text-align: center;">NO</th>
                        <th style="display: none;">ID PRODUK</th>
                        <th style="width: 28%;">NAMA PRODUK</th>
                        <th style="display: none;">ID KEMASAN</th>
                        <th style="width: 8%; text-align: center;">KEMASAN</th>
						<th style="width: 15%; text-align: center;">BATCH NUMBER</th>
						<th style="width: 15%; text-align: right;">EXPIRED DATE</th>
						<th style="text-align: right;">JUMLAH</th>
						<th style="text-align: right;">HARGA</th>
						<th style="text-align: right;">TOTAL</th>
						<th style="text-align: right;">DISC.</th>
						<th style="text-align: right;">NETTO</th>
						<th style="width: 9%; text-align: center;">ACTIONS</th>
                    </tr>
                </thead>
				<tbody id="show_detail">

                </tbody>                
            </table>
            
            <div id="responsecontainer" align="center"></div>
            
        </div>
    </div>
</div>

<div class="block b-footer">
	<form class="form-horizontal">
		<div class="row margin-bottom-5">
			<div class="form-group">
				<div class="col-md-7">
					<label class="control-label pull-right">Total Barang : </label>			
				</div>
				<div class="col-md-5">
					<div class="input-group">
						<span class="input-group-addon">Rp.</span>
						<input id="txttotalbarang_hdr" name="txttotalbarang_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($total_barang); ?>" readonly>
					</div>
				</div>
			</div>
		</div>
		<div class="row margin-bottom-5">
			<div class="form-group">
				<div class="col-md-7">
					<label class="control-label pull-right">Disc. : </label>			
				</div>
				<div class="col-md-2">
					<div class="input-group">						
						<input id="txtdiscpersen_hdr" name="txtdiscpersen_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($disc_persen, 1); ?>">
						<span class="input-group-addon">%</span>
					</div>
				</div>
				<div class="col-md-3">
					<div class="input-group">	
						<span class="input-group-addon">Rp.</span>
						<input id="txtdiscrupiah_hdr" name="txtdiscrupiah_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($disc_rp); ?>">						
					</div>
				</div>
			</div>
		</div>
		<div class="row margin-bottom-5">
			<div class="form-group">
				<div class="col-md-7">
					<label class="control-label pull-right">DPP : </label>			
				</div>
				<div class="col-md-5">
					<div class="input-group">
						<span class="input-group-addon">Rp.</span>
						<input id="txtdpp_hdr" name="txtdpp_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($dpp); ?>" readonly>
					</div>
				</div>
			</div>
		</div>
		<div class="row margin-bottom-5">
			<div class="form-group">
				<div class="col-md-7">
					<label class="control-label pull-right">PPN : </label>			
				</div>
				<div class="col-md-2">
					<div class="input-group">						
						<input id="txtppnpersen_hdr" name="txtppnpersen_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($ppn_persen); ?>">
						<span class="input-group-addon">%</span>
					</div>
				</div>
				<div class="col-md-3">
					<div class="input-group">	
						<span class="input-group-addon">Rp.</span>
						<input id="txtppnrupiah_hdr" name="txtppnrupiah_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($ppn_rp); ?>" readonly>
					</div>
				</div>
			</div>
		</div>
		<div class="row margin-bottom-5">
			<div class="form-group">
				<div class="col-md-7">
					<label class="control-label pull-right">Biaya Materai : </label>			
				</div>
				<div class="col-md-5">
					<div class="input-group">
						<span class="input-group-addon">Rp.</span>
						<input id="txtmaterai_hdr" name="txtmaterai_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($materai); ?>">
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="form-group">
				<div class="col-md-7">
					<label class="control-label pull-right">Grand Total : </label>			
				</div>
				<div class="col-md-5">
					<div class="input-group">
						<span class="input-group-addon">Rp.</span>
						<input id="txtgrandtotal_hdr" name="txtgrandtotal_hdr" type="text" class="form-control text-right text-xlg text-bolder" value="<?php echo number_format($grand_total); ?>" readonly>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>

<?php
	if ($validasi == '0') {
?>	
<div class="block">
	<div class="row pull-right">	
		<div class="col-md-12">
			<button class="btn btn-success btn-icon-fixed" id="simpan_header"><span class="icon-floppy-disk"></span> Simpan</button>
		</div>
	</div>
</div>
<?php
	}
?>
<!-- End : Block Detail -->

<!-- Begin : Modal Edit Detail -->
<div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="modal-primary-header">                        
	<div class="modal-dialog modal-primary" role="document">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="icon-cross"></span></button>
        <div class="modal-content">
            <div class="modal-header">                        
                <h4 class="modal-title" id="modal-primary-header">Edit Data Detail</h4>
            </div>
            <input type="hidden" id="txtid_edit" class="form-control" />
            <div class="modal-body">
				<div class="row">
					<div class="col-md-12">
						<label>Nama Produk</label>
						<div class="input-group group-namaproduk-edit">
							<input id="txtnamaproduk_edit" name="txtnamaproduk_edit" type="text" class="form-control" readonly>
							<input id="txtidproduk_edit" name="txtidproduk_edit" type="hidden" class="form-control" readonly>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<label class="pull-right">Jumlah</label>
						<div class="input-group group-jumlah-edit">
							<input id="txtjumlah_edit" name="txtjumlah_edit" type="text" class="form-control" style="text-align: right" value="0" onkeypress="return hanya_angka(event)">
							<input id="txtjumlah_edit_hidden" name="txtjumlah_edit_hidden" type="hidden" class="form-control" style="text-align: right" value="0">
						</div>
					</div>
					<div class="col-md-4">
						<label class="pull-right">Harga Satuan</label>
						<div class="input-group group-hargasatuan-edit">
							<input id="txthargasatuan_edit" name="txthargasatuan_edit" type="text" class="form-control" style="text-align: right" value="0" onkeypress="return hanya_angka(event)">
							<input id="txthargasatuan_edit_hidden" name="txthargasatuan_edit_hidden" type="hidden" class="form-control" style="text-align: right" value="0">
						</div>
					</div>
					<div class="col-md-4">
						<label class="pull-right">Total</label>
						<div class="input-group group-total-edit">
							<input id="txttotal_edit" name="txttotal_edit" type="text" class="form-control" style="text-align: right" value="0" onkeypress="return hanya_angka(event)" readonly>
							<input id="txttotal_edit_hidden" name="txttotal_edit_hidden" type="hidden" class="form-control" style="text-align: right" value="0">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<label class="pull-right">Disc. %</label>
						<div class="input-group group-discpersen-edit">
							<input id="txtdiscpersen_edit" name="txtdiscpersen_edit" type="text" class="form-control" style="text-align: right" value="0" onkeypress="return hanya_angka(event)">
							<input id="txtdiscpersen_edit_hidden" name="txtdiscpersen_edit_hidden" type="hidden" class="form-control" style="text-align: right" value="0">
						</div>
					</div>
					<div class="col-md-4">
						<label class="pull-right">Disc. Rp.</label>
						<div class="input-group group-discrupiah-edit">
							<input id="txtdiscrupiah_edit" name="txtdiscrupiah_edit" type="text" class="form-control" style="text-align: right" value="0" onkeypress="return hanya_angka(event)">
							<input id="txtdiscrupiah_edit_hidden" name="txtdiscrupiah_edit_hidden" type="hidden" class="form-control" style="text-align: right" value="0">
						</div>
					</div>
					<div class="col-md-4">
						<label class="pull-right">Netto</label>
						<div class="input-group group-netto-edit">
							<input id="txtnetto_edit" name="txtnetto_edit" type="text" class="form-control" style="text-align: right" value="0" onkeypress="return hanya_angka(event)" readonly>
							<input id="txtnetto_edit_hidden" name="txtnetto_edit_hidden" type="hidden" class="form-control" style="text-align: right" value="0">
						</div>
					</div>
				</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>					
                <button type="button" class="btn btn-primary" id="simpan_detail">Simpan</button>					
            </div>
        </div>
	</div>            
</div>
<!-- End : Modal Edit Detail -->