<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
    
    $id_transaksi = '';
    $no_transaksi = ''; 
	$tgl_transaksi = ''; 
    $supplier_id = '';
	$nama_supplier = '';
	$keterangan = '';

    if ($get_header->num_rows() > 0) {
        foreach($get_header->result() as $row) {
			$id_transaksi = $row->id;
			$no_transaksi = $row->no_transaksi; 
			$tgl_transaksi = $row->tgl_transaksi; 
			$supplier_id = $row->supplier_id;
			$nama_supplier = $row->nama_supplier;
			$keterangan = $row->keterangan;
        } 
    }
?>

<!-- Begin : Block Header -->
<div class="block">
	<div class="row">
		<div class="col-md-4">
			<div class="row">
				<div class="col-md-6">
					<label>No. Transaksi</label>
					<div class="input-group">
						<input id="txtnotransaksi_hdr" name="txtnotransaksi_hdr" type="text" class="form-control input-sm" value="<?php echo $no_transaksi; ?>" readonly>
						<input id="txtidtransaksi_hdr" name="txtidtransaksi_hdr" type="hidden" class="form-control" value="<?php echo $id_transaksi; ?>" readonly>
					</div>
				</div>
				<div class="col-md-6">
					<label>Tgl. Transaksi</label>
					<div class="input-group">
						<input id="txttgltransaksi_hdr" name="txttgltransaksi_hdr" type="text" class="form-control input-sm" value="<?php echo date_format(new DateTime($tgl_transaksi), $this->config->item('FORMAT_DATE_TO_DISPLAY')); ?>" readonly>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<label>Supplier</label>
					<div class="input-group">
						<input id="txtnamasupplier_hdr" name="txtnamasupplier_hdr" type="text" class="form-control input-sm" value="<?php echo $nama_supplier; ?>" readonly>
						<input id="txtsupplierid_hdr" name="txtsupplierid_hdr" type="hidden" class="form-control input-sm" value="<?php echo $supplier_id; ?>" readonly>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-8">
			<div class="row">
				<div class="col-md-12">
					<label>Keterangan</label>
					<div class="input-group">
						<textarea id="txtketerangan_hdr" name="txtketerangan_hdr" class="form-control" rows="4"><?php echo $keterangan; ?></textarea>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-4">
			<button class="btn btn-success btn-icon-fixed" id="simpan_header"><span class="icon-floppy-disk"></span> Simpan</button>
		</div>
	</div>
</div>
<!-- End : Block Header -->

<!-- Begin : Block Detail -->
<div class="block">	
	<div class="row">
		<div class="col-md-2 pull-right">
			<label>&nbsp;</label>
			<div class="input-group">
				<button id="simpan_detail" type="submit" class="btn btn-warning btn-icon-fixed pull-right"><span class="icon-plus"></span> Data Dari GR</button>
			</div>
		</div>
	</div>
	
    <div class="row">
        <div class="col-md-12">            
            <table id="table_detail" class="table table-head-custom table-striped" style="width: 100%;">
                <thead>
                    <tr>
                        <th style="width: 4%; text-align: center;">NO</th>
                        <th style="display: none;">GR ID</th>
                        <th style="text-align: center;">NO GR</th>
						<th style="text-align: center;">TGL. GR</th>
						<th style="text-align: center;">TGL. TERIMA</th>
						<th style="text-align: center;">NO. SJ SUPPLIER</th>
                        <th style="display: none;">PO ID</th>
                        <th style="text-align: center;">NO PO</th>
						<th style="text-align: center;">TGL. PO</th>
						<th style="width: 9%; text-align: center;"><input type="checkbox" name="check_all" id="check_all" value=""/></th>
                    </tr>
                </thead>
				<tbody>
					<?php
						if ($get_detail->num_rows() > 0) {
							$i = 1;
							foreach ($get_detail->result() as $r) {
								echo "<tr>";
									echo "<td style='width: 4%; text-align: center;'>".$i."</td>";								
									echo "<td id='gr_id' style='display:none;'>".$r->gr_id."</td>";
									echo "<td id='no_gr' style='text-align: center;'>".$r->no_gr."</td>";
									echo "<td id='tgl_gr' style='text-align: center;'>".date_format(new DateTime($r->tgl_gr), $this->config->item('FORMAT_DATE_TO_DISPLAY'))."</td>";
									echo "<td id='tgl_terima' style='text-align: center;'>".date_format(new DateTime($r->tgl_terima), $this->config->item('FORMAT_DATE_TO_DISPLAY'))."</td>";
									echo "<td id='no_sj_supplier' style='text-align: center;'>".$r->no_sj_supplier."</td>";
									echo "<td id='po_id' style='display:none;'>".$r->po_id."</td>";
									echo "<td id='no_po' style='text-align: center;'>".$r->no_po."</td>";
									echo "<td id='tgl_po' style='text-align: center;'>".date_format(new DateTime($r->tgl_po), $this->config->item('FORMAT_DATE_TO_DISPLAY'))."</td>";
									echo "<td style='width: 9%; text-align: center;'>";
										echo '<input type="checkbox" name="selected_id[]" class="checkbox" value="<?php echo $gr_id; ?>"/>';
									echo "</td>";
								echo "</tr>";
								
								$i++;
							}
						}
					?>
                </tbody>                
            </table>
            
            <div id="responsecontainer" align="center"></div>
            
        </div>
    </div>
</div>
<!-- End : Block Detail -->