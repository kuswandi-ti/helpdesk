<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase_Order extends CI_Controller {
    
    var $view_po_hdr			= 'ck_view_beli_po_hdr';
	var $view_po_hdr_draft		= 'ck_view_beli_po_hdr_draft';
	var $view_po_hdr_pending	= 'ck_view_beli_po_hdr_pending';
	var $view_po_hdr_approve	= 'ck_view_beli_po_hdr_approve';
	var $view_po_hdr_revisi		= 'ck_view_beli_po_hdr_revisi';
	var $view_po_hdr_reject		= 'ck_view_beli_po_hdr_reject';

	public function __construct() {
		parent::__construct();
		$this->load->view('theme_default/setting'); 
		$this->load->model('M_Purchase_Order');
	}
	
	public function index() {
		$data = array(
			'title' => 'Purchase Order (PO)',
			'breadcrumb_home_active' => '',
            'breadcrumb' => '<li>Pembelian</li>
                             <li><a href="pembelian/purchase_order">Purchase Order (PO)</a></li>',
			'page_icon' => 'icon-clipboard-text',
			'page_title' => 'Purchase Order (PO)',
			'page_subtitle' => 'Pemesanan pembelian barang ke supplier',
			'get_tipe_pembayaran' => $this->M_Purchase_Order->get_tipe_pembayaran(),
			'custom_scripts' => "<script type='text/javascript' src='assets/custom_script/beli_purchase_order.js'></script>"
		);
		$this->template->build('v_purchase_order', $data);
	}
	
	public function get_data($status_po) {		
		/* 
		 * Array of database columns which should be read and sent back to DataTables. Use a space where
         * you want to insert a non-database field (for example a counter or static image)
         */
        $aColumns = array('po_id', 'po_no', 'tgl_po', 'bulan', 'tahun', 'supplier_id', 'nama_supplier', 'keterangan', 'pr_no', 'status_po', 'nama_status_po', 'status_histori', 'grand_total');
        
        // DB table to use
		if ($status_po == '1') {
			$sTable = $this->view_po_hdr_draft;
			$label = 'label-default';
		} elseif ($status_po == '2') {
			$sTable = $this->view_po_hdr_pending;
			$label = 'label-success';
		} elseif ($status_po == '3') {
			$sTable = $this->view_po_hdr_approve;
			$label = 'label-info';
		} elseif ($status_po == '4') {
			$sTable = $this->view_po_hdr_revisi;
			$label = 'label-warning';
		} elseif ($status_po == '5') {
			$sTable = $this->view_po_hdr_reject;
			$label = 'label-danger';
		}
    
        $iDisplayStart = $this->input->get_post('iDisplayStart', true);
        $iDisplayLength = $this->input->get_post('iDisplayLength', true);
        $iSortCol_0 = $this->input->get_post('iSortCol_0', true);
        $iSortingCols = $this->input->get_post('iSortingCols', true);
        $sSearch = $this->input->get_post('sSearch', true);
        $sEcho = $this->input->get_post('sEcho', true);
		
        // Paging
        if (isset($iDisplayStart) && $iDisplayLength != '-1') {
            $this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
        }
        
        // Ordering
        if (isset($iSortCol_0)) {
            for ($i=0; $i<intval($iSortingCols); $i++) {
                $iSortCol = $this->input->get_post('iSortCol_'.$i, true);
                $bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
                $sSortDir = $this->input->get_post('sSortDir_'.$i, true);
    
                if ($bSortable == 'true') {
                    $this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
                }
            }
        }
        
        /* 
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        if (isset($sSearch) && !empty($sSearch)) {
            for ($i=0; $i<count($aColumns); $i++) {
                $bSearchable = $this->input->get_post('bSearchable_'.$i, true);
                
                // Individual column filtering
                if (isset($bSearchable) && $bSearchable == 'true') {
                    $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
                }
            }
        }
        
        // Select Data
        $this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
        $rResult = $this->db->get($sTable);
		//$rResult = $this->db->get_where($sTable, array('status_po' => $status_po));
    
        // Data set length after filtering
        $this->db->select('FOUND_ROWS() AS found_rows');
        $iFilteredTotal = $this->db->get()->row()->found_rows;
    
        // Total data set length
        $iTotal = $this->db->count_all($sTable);
    
        // Output
        $output = array(
            'sEcho' => intval($sEcho),
            'iTotalRecords' => $iTotal,
            'iTotalDisplayRecords' => $iFilteredTotal,
            'aaData' => array()
        );
        
		$no = $iDisplayStart;
		
        foreach ($rResult->result_array() as $aRow) {
            $row = array();
			
			$no++;
			$row[] = $no;
			$row[] = $aRow['po_no'];
			$row[] = $aRow['tgl_po'];
			$row[] = set_month_to_string_ind($aRow['bulan']);
			$row[] = $aRow['tahun'];
			$row[] = $aRow['nama_supplier'];
            $row[] = $aRow['keterangan'];			
            $row[] = $aRow['pr_no'];
			$row[] = "<span class='label $label'>".$aRow['nama_status_po']."</span>";
			$row[] = '<button value="'.$aRow['status_histori'].'" id="btn_'.$aRow['po_id'].'" class="histori btn btn-default btn-sm btn-clean" title="Tampilkan histori"><span class="fa fa-play"></span></button>';
			$row[] = number_format($aRow['grand_total']);
            if ($aRow['status_po'] == 1 || $aRow['status_po'] == 4) {
                $row[] = '<a title="Edit Detail" href="pembelian/purchase_order/purchase_order_detail/?hid='.$aRow['po_id'].'&sid='.$aRow['supplier_id'].'"><span class="icon-pencil5"></span></a>&nbsp;&nbsp;
                          <a title="Siap Approve" href="pembelian/purchase_order/send_to_approve/'.$aRow['po_id'].'" onclick="return confirm(\'Yakin akan melanjutkan ke proses approve ?\')"><span class="icon-paper-plane"></span></a>&nbsp;&nbsp;
					      <a title="Print" href="#"><span class="icon-printer"></span></a>';
            } elseif ($aRow['status_po'] == 2 || $aRow['status_po'] == 3 || $aRow['status_po'] == 5) {
                $row[] = '<a title="Lihat Detail" href="pembelian/purchase_order/purchase_order_detail/?hid='.$aRow['po_id'].'&sid='.$aRow['supplier_id'].'"><span class="icon-text-align-justify"></span></a>&nbsp;&nbsp;
					      <a title="Print" href="#"><span class="icon-printer"></span></a>';
            }
			
			$output['aaData'][] = $row;
        }
        echo json_encode($output);
    }
	
	function create_header() {		
        $data = array(
            'pr_id'                 => $this->input->post('txtidpr'),
			'no_transaksi'          => $this->M_Purchase_Order->create_doc_no(date('n'), date('Y')),
			'tgl_transaksi'         => date('Y-m-d'),
			'bulan'					=> $this->input->post('cbobulan'),
			'tahun'					=> $this->input->post('cbotahun'),
            'supplier_id'           => $this->input->post('cbosupplier'),
            'alamat_pengiriman'     => $this->input->post('txtalamatpengiriman'),
            'tipe_pembayaran'       => $this->input->post('cbotipepembayaran'),
			'top'					=> $this->input->post('txttop'),
            'tgl_pengiriman'       	=> date_format(new DateTime($this->input->post('txttglpengiriman')), $this->config->item('FORMAT_DATE_TO_INSERT')),
			'keterangan'           	=> $this->input->post('txtketerangan'),
			'status_histori'		=> '',
			'created_by'            => $this->session->userdata('user_name'),
			'created_date'          => date('Y-m-d H:i:s'),
			'modified_by'           => $this->session->userdata('user_name'),
			'modified_date'         => date('Y-m-d H:i:s')
        );
		$create_header = $this->M_Purchase_Order->header_create($data);	
		$hid = $this->session->userdata('hid');
		$sid = $this->input->post('cbosupplier');
		$pr_id = $this->input->post('txtidpr');
		if ($create_header) {
			//$this->M_Purchase_Order->update_status_pr($pr_id);
			redirect('pembelian/purchase_order/purchase_order_detail/?hid='.$hid.'&sid='.$sid);
		} else {
			echo "<script>alert('Fail')</script>";
		}		 
	}
	
	function get_pr_aktif() {
        $data = $this->M_Purchase_Order->get_pr_aktif();
        header('Content-Type: application/json');
        echo json_encode($data);
    }
	
	function supplier_per_pr() {
		$pr_id = $this->input->post('pr_id');
		$data = $this->M_Purchase_Order->supplier_per_pr($pr_id);
        if ($data->num_rows() > 0) {
			foreach($data->result() as $r) {
				echo "<option value='$r->supplier_id'>".$r->nama_supplier."</option>";
			}
        }
	}
	
	function purchase_order_detail() {
		$hid = $_GET['hid'];
		$sid = $_GET['sid'];
				
		$data = array(
			'title' => 'Purchase Order (PO)',
			'breadcrumb_home_active' => '',
            'breadcrumb' => '<li>Pembelian</li>
                             <li><a href="pembelian/purchase_order">Purchase Order (PO)</a></li>
							 <li>Purchase Order (PO) Detail</li>',
			'page_icon' => 'icon-clipboard-text',
			'page_title' => '',
			'page_subtitle' => '',			
			'custom_scripts' => "<script type='text/javascript' src='assets/custom_script/beli_purchase_order.js'></script>",
			'get_header' => $this->M_Purchase_Order->get_header($hid),
            'get_detail' => $this->M_Purchase_Order->get_detail($hid),
            'get_produk_pr' => $this->M_Purchase_Order->get_produk_pr($hid, $sid),
            'get_produk_supplier' => $this->M_Purchase_Order->get_produk_supplier($sid),
			'get_tipe_pembayaran' => $this->M_Purchase_Order->get_tipe_pembayaran()
		);
		$this->template->build('v_purchase_order_detail', $data);		
	}
    
    function detail_list() {
		$hid = $this->input->get('hid');
        $data = $this->M_Purchase_Order->detail_list($hid);
		$status_po = $this->M_Purchase_Order->get_status_po($hid);
        if ($data->num_rows() > 0) {
            $i = 1;
            foreach ($data->result() as $row) {
                echo '<tr>';
                echo    '<td id="id" style="display:none;">'.$row->id.'</td>';
                echo    '<td id="no" style="width: 4%; text-align: center;">'.$i.'</td>';
                echo    '<td id="produk_id" style="display:none;">'.$row->produk_id.'</td>';
                echo    '<td id="nama_produk" style="width: 29%;">'.$row->nama_produk.'</td>';
                echo    '<td id="kemasan_id" style="display:none;">'.$row->kemasan_id.'</td>';
                echo    '<td id="nama_kemasan" style="width: 6%; text-align: center;">'.$row->nama_kemasan.'</td>';
                echo    '<td id="qty_po" style="width: 8%; text-align: right;">'.number_format($row->qty_po).'</td>';
				echo    '<td id="harga_satuan" style="width: 10%; text-align: right;">'.number_format($row->harga_satuan).'</td>';
				echo    '<td id="total" style="width: 10%; text-align: right;">'.number_format($row->total).'</td>';
				echo    '<td id="disc_persen" style="width: 6%; text-align: right;">'.number_format($row->disc_persen).'</td>';
				echo    '<td id="disc_rupiah" style="width: 8%; text-align: right;">'.number_format($row->disc_rupiah).'</td>';
				echo    '<td id="netto" style="width: 10%; text-align: right;">'.number_format($row->netto).'</td>';
                echo    '<td style="width: 9%; text-align: center;">';
				if ($status_po == '2' or $status_po == '3' or $status_po == '5' or $status_po == '6') {
					echo '-';
				} else {
					echo '<span id="edit_detail" title="Edit" class="icon-register text-info text-lg" style="cursor: pointer"></span>&nbsp;
                          <span id="hapus_detail" title="Hapus" class="icon-trash2 text-danger text-lg" style="cursor: pointer"></span>';
				}       
                echo    '</td>';
                echo '</tr>';
                
                $i++;
            }
        }		
    }  
    
	function create_detail() {
        $data = array(
            'header_id'             => $this->input->post('header_id'),
            'produk_id'             => $this->input->post('produk_id'),
			'tgl_pengiriman'        => date_format(new DateTime($this->input->post('tgl_pengiriman')), $this->config->item('FORMAT_DATE_TO_INSERT')),
            'qty_po'             	=> $this->input->post('qty_po'),
            'created_by'            => $this->session->userdata('user_name'),
            'created_date'          => date('Y-m-d H:i:s'),
            'modified_by'           => $this->session->userdata('user_name'),
            'modified_date'         => date('Y-m-d H:i:s')
        );
        $create_detail = $this->M_Purchase_Order->detail_create($data);
        if ($create_detail) {
            $set_header = $this->M_Purchase_Order->get_total_barang_detail(
                                $this->input->post('header_id'),
                                $this->input->post('disc_persen_hdr'),
                                $this->input->post('disc_rp_hdr'),
                                $this->input->post('ppn_persen_hdr'),
                                $this->input->post('materai')
                          );
            $result = array();
            foreach ($set_header->result_array() as $row) {
                $data['result'] = 'done';
                $data['total_barang'] = $row['total_barang']; 
                $data['disc_persen'] = $row['disc_persen']; 
                $data['disc_rupiah'] = $row['disc_rupiah']; 
                $data['dpp'] = $row['dpp']; 
                $data['ppn_persen'] = $row['ppn_persen']; 
                $data['ppn_rupiah'] = $row['ppn_rupiah']; 
                $data['materai'] = $row['materai']; 
                $data['grand_total'] = $row['grand_total'];
            }
            echo json_encode($data);
        } else {
            echo "fail";
		}
    }
		
    function delete_item_detail() {        
        $del = $this->M_Purchase_Order->delete_item_detail();        
        if ($del) {
            $set_header = $this->M_Purchase_Order->get_total_barang_detail(
                                $this->input->post('header_id'),
                                $this->input->post('disc_persen_hdr'),
                                $this->input->post('disc_rupiah_hdr'),
                                $this->input->post('ppn_persen_hdr'),
                                $this->input->post('materai')
                          );
            $result = array();
            foreach ($set_header->result_array() as $row) {
                $data['result'] = 'done';
                $data['total_barang'] = $row['total_barang']; 
                $data['disc_persen'] = $row['disc_persen']; 
                $data['disc_rupiah'] = $row['disc_rupiah']; 
                $data['dpp'] = $row['dpp']; 
                $data['ppn_persen'] = $row['ppn_persen']; 
                $data['ppn_rupiah'] = $row['ppn_rupiah']; 
                $data['materai'] = $row['materai']; 
                $data['grand_total'] = $row['grand_total'];
            }
            echo json_encode($data);
        } else {
            echo "fail";
		}
    }
    
    function update_item_detail() {		
        $del = $this->M_Purchase_Order->update_item_detail();
        if ($del) {
            $set_header = $this->M_Purchase_Order->get_total_barang_detail(
                                $this->input->post('header_id'),
                                $this->input->post('disc_persen_hdr'),
                                $this->input->post('disc_rupiah_hdr'),
                                $this->input->post('ppn_persen_hdr'),
                                $this->input->post('materai')
                          );
            $result = array();
            foreach ($set_header->result_array() as $row) {
                $data['result'] = 'done';
                $data['total_barang'] = $row['total_barang']; 
                $data['disc_persen'] = $row['disc_persen']; 
                $data['disc_rupiah'] = $row['disc_rupiah']; 
                $data['dpp'] = $row['dpp']; 
                $data['ppn_persen'] = $row['ppn_persen']; 
                $data['ppn_rupiah'] = $row['ppn_rupiah']; 
                $data['materai'] = $row['materai']; 
                $data['grand_total'] = $row['grand_total'];
            }
            echo json_encode($data);
        } else {
            echo "fail";
		}
    }
		
	function update_header() {
        $del = $this->M_Purchase_Order->update_header();
        if ($del)
            echo "done";
        else
            echo "fail";
    }
    
    function send_to_approve() {
        $id = $this->uri->segment('4');
        $na = $this->M_Purchase_Order->send_to_approve($id);
        
        if ($na)
            redirect('pembelian/purchase_order/');
        else
            redirect('/');
            
    }
	
	function get_info_pr() {
		$pr_id = $this->input->post('pr_id');
		$produk_id = $this->input->post('produk_id');
        $data = $this->M_Purchase_Order->get_info_pr($pr_id, $produk_id);
        header('Content-Type: application/json');
        echo json_encode($data);
    }
	
	function get_data_pr() {
		$del = $this->M_Purchase_Order->get_data_pr();
        if ($del)
            echo "done";
        else
            echo "fail";
	}

} 