<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Validasi_Tagihan extends CI_Controller {
    
    var $table_penerimaantagihan_header			= 'ck_penerimaantagihan_header';
	var $table_penerimaantagihan_detail  		= 'ck_penerimaantagihan_detail';
	var $view_penerimaantagihan_header			= 'ck_penerimaantagihan_header_view';
	var $view_penerimaantagihan_validasi_header	= 'ck_penerimaantagihan_header_validasi_view';

	public function __construct() {
		parent::__construct();
		$this->load->view('theme_default/setting'); 
		$this->load->model('M_Validasi_Tagihan');
	}
	
	public function index() {
		$data = array(
			'title' => 'Validasi Tagihan',
			'breadcrumb_home_active' => '',
            'breadcrumb' => '<li>Pembelian</li>
                             <li><a href="pembelian/validasi_tagihan">Validasi Tagihan</a></li>',
			'page_icon' => 'icon-list3',
			'page_title' => 'Validasi Tagihan',
			'page_subtitle' => 'Validasi tagihan supplier',
			'custom_scripts' => "<script type='text/javascript' src='assets/custom_script/validasi_tagihan.js'></script>"
		);
		$this->template->build('v_validasi_tagihan', $data);
	}
	
	public function get_data() {
		/* 
		 * Array of database columns which should be read and sent back to DataTables. Use a space where
         * you want to insert a non-database field (for example a counter or static image)
         */
        $aColumns = array('id', 'no_transaksi', 'tgl_transaksi', 'supplier_id', 'nama_supplier', 'no_invoice_supplier', 'tgl_invoice_supplier', 'tgl_jatuh_tempo', 'keterangan', 'grand_total', 'validasi', 'no_gr');
        
        // DB table to use
        $sTable = $this->view_penerimaantagihan_validasi_header;
    
        $iDisplayStart = $this->input->get_post('iDisplayStart', true);
        $iDisplayLength = $this->input->get_post('iDisplayLength', true);
        $iSortCol_0 = $this->input->get_post('iSortCol_0', true);
        $iSortingCols = $this->input->get_post('iSortingCols', true);
        $sSearch = $this->input->get_post('sSearch', true);
        $sEcho = $this->input->get_post('sEcho', true);
    
        // Paging
        if (isset($iDisplayStart) && $iDisplayLength != '-1') {
            $this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
        }
        
        // Ordering
        if (isset($iSortCol_0)) {
            for ($i=0; $i<intval($iSortingCols); $i++) {
                $iSortCol = $this->input->get_post('iSortCol_'.$i, true);
                $bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
                $sSortDir = $this->input->get_post('sSortDir_'.$i, true);
    
                if ($bSortable == 'true') {
                    $this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
                }
            }
        }
        
        /* 
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        if (isset($sSearch) && !empty($sSearch)) {
            for ($i=0; $i<count($aColumns); $i++) {
                $bSearchable = $this->input->get_post('bSearchable_'.$i, true);
                
                // Individual column filtering
                if (isset($bSearchable) && $bSearchable == 'true') {
                    $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
                }
            }
        }
        
        // Select Data
        $this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
        $rResult = $this->db->get($sTable);
    
        // Data set length after filtering
        $this->db->select('FOUND_ROWS() AS found_rows');
        $iFilteredTotal = $this->db->get()->row()->found_rows;
    
        // Total data set length
        $iTotal = $this->db->count_all($sTable);
    
        // Output
        $output = array(
            'sEcho' => intval($sEcho),
            'iTotalRecords' => $iTotal,
            'iTotalDisplayRecords' => $iFilteredTotal,
            'aaData' => array()
        );
        
		$no = $iDisplayStart;
		
        foreach ($rResult->result_array() as $aRow) {
            $row = array();
			
			$no++;
			$row[] = $no;
			$row[] = $aRow['no_transaksi'];
			$row[] = date_format(new DateTime($aRow['tgl_transaksi']), $this->config->item('FORMAT_DATE_TO_DISPLAY'));
			$row[] = $aRow['no_gr'];
			$row[] = $aRow['supplier_id'];
			$row[] = $aRow['nama_supplier'];
			$row[] = $aRow['no_invoice_supplier'];			
			$row[] = date_format(new DateTime($aRow['tgl_invoice_supplier']), $this->config->item('FORMAT_DATE_TO_DISPLAY'));
			$row[] = date_format(new DateTime($aRow['tgl_jatuh_tempo']), $this->config->item('FORMAT_DATE_TO_DISPLAY'));
			$row[] = $aRow['keterangan'];			
			$row[] = number_format($aRow['grand_total']);
			if ($aRow['validasi'] == '0') {
				$row[] = "<span class='icon-cross2'></span>";	
			} else {
				$row[] = "<span class='icon-check'></span>";
			}
			$row[] = '<a title="Edit Detail" href="pembelian/validasi_tagihan/validasi_tagihan_detail/?hid='.$aRow['id'].'&sid='.$aRow['supplier_id'].'"><span class="icon-pencil4"></span></a>&nbsp;&nbsp;
					  <a title="Print" href="#"><span class="icon-printer"></span></a>';
			
			$output['aaData'][] = $row;
        }
        echo json_encode($output);
    }
	
	function validasi_tagihan_detail() {
		$hid = $_GET['hid'];
		$sid = $_GET['sid'];
		$this->session->set_userdata('hid', $hid);
				
		$data = array(
			'title' => 'Validasi Tagihan',
			'breadcrumb_home_active' => '',
            'breadcrumb' => '<li>Pembelian</li>
                             <li><a href="pembelian/validasi_tagihan">Validasi Tagihan</a></li>
							 <li>Validasi Tagihan Detail</li>',
			'page_icon' => 'icon-list3',
			'page_title' => '',
			'page_subtitle' => '',			
			'custom_scripts' => "<script type='text/javascript' src='assets/custom_script/validasi_tagihan.js'></script>",
			'get_header' => $this->M_Validasi_Tagihan->get_header($hid),
			'get_detail' => $this->M_Validasi_Tagihan->get_detail($hid)
		);
		$this->template->build('v_validasi_tagihan_detail', $data);		
	}
	
	function detail_list() {
        $data = $this->M_Validasi_Tagihan->detail_list($this->session->userdata('hid'));
        if ($data->num_rows() > 0) {
            $i = 1;
            foreach ($data->result() as $row) {
				echo '<tr>';
				echo    '<td id="id" style="display:none;">'.$row->detail_id.'</td>';
				echo    '<td id="no" style="width: 4%; text-align: center;">'.$i.'</td>';
				echo    '<td id="produk_id" style="display:none;">'.$row->produk_id.'</td>';
				echo    '<td id="nama_produk" style="width: 28%;">'.$row->nama_produk.'</td>';
				echo    '<td id="kemasan_id" style="display:none;">'.$row->kemasan_id.'</td>';
				echo    '<td id="nama_kemasan" style="width: 8%; text-align: center;">'.$row->nama_kemasan.'</td>';
				echo    '<td id="batch_number" style="width: 15%; text-align: center;">'.$row->batch_number.'</td>';
				echo    '<td id="expired_date" style="width: 15%; text-align: right;">'.date_format(new DateTime($row->expired_date), $this->config->item('FORMAT_DATE_TO_DISPLAY')).'</td>';
				echo    '<td id="jumlah" style="text-align: right;">'.number_format($row->jumlah).'</td>';
				echo    '<td id="harga_satuan" style="text-align: right;">'.number_format($row->harga_satuan).'</td>';
				echo    '<td id="total" style="text-align: right;">'.number_format($row->total).'</td>';
				echo    '<td id="disc_persen" style="display:none;">'.number_format($row->disc_persen, 1).'</td>';
				echo    '<td id="disc_rupiah" style="text-align: right;">'.number_format($row->disc_rupiah).'</td>';
				echo    '<td id="netto" style="text-align: right;">'.number_format($row->netto).'</td>';
				echo '</tr>';
				
				$i++;
            }
        }		
    }
	
	function update_header() {		
        $del = $this->M_Validasi_Tagihan->update_header();
        if ($del)
            echo "done";
        else
            echo "fail";
    }

} 