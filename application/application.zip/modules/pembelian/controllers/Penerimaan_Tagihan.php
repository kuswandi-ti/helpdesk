<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Penerimaan_Tagihan extends CI_Controller {
    
    var $table_penerimaantagihan_header		= 'ck_penerimaantagihan_header';
	var $table_penerimaantagihan_detail  	= 'ck_penerimaantagihan_detail';
	var $view_penerimaantagihan_header		= 'ck_penerimaantagihan_header_view';

	public function __construct() {
		parent::__construct();
		$this->load->view('theme_default/setting'); 
		$this->load->model('M_Penerimaan_Tagihan');
	}
	
	public function index() {
		$data = array(
			'title' => 'Penerimaan Tagihan',
			'breadcrumb_home_active' => '',
            'breadcrumb' => '<li>Pembelian</li>
                             <li><a href="pembelian/penerimaan_tagihan">Penerimaan Tagihan</a></li>',
			'page_icon' => 'icon-new-tab',
			'page_title' => 'Penerimaan Tagihan',
			'page_subtitle' => 'Penerimaan invoice pembelian dari supplier',
			'get_supplier' => $this->M_Penerimaan_Tagihan->get_supplier(),
			'custom_scripts' => "<script type='text/javascript' src='assets/custom_script/penerimaan_tagihan.js'></script>"
		);
		$this->template->build('v_penerimaan_tagihan', $data);
	}
	
	public function get_data() {
		/* 
		 * Array of database columns which should be read and sent back to DataTables. Use a space where
         * you want to insert a non-database field (for example a counter or static image)
         */
        $aColumns = array('id', 'no_transaksi', 'tgl_transaksi', 'supplier_id', 'nama_supplier', 'no_invoice_supplier', 'tgl_invoice_supplier', 'tgl_jatuh_tempo', 'keterangan', 'grand_total', 'validasi', 'no_gr');
        
        // DB table to use
        $sTable = $this->view_penerimaantagihan_header;
    
        $iDisplayStart = $this->input->get_post('iDisplayStart', true);
        $iDisplayLength = $this->input->get_post('iDisplayLength', true);
        $iSortCol_0 = $this->input->get_post('iSortCol_0', true);
        $iSortingCols = $this->input->get_post('iSortingCols', true);
        $sSearch = $this->input->get_post('sSearch', true);
        $sEcho = $this->input->get_post('sEcho', true);
    
        // Paging
        if (isset($iDisplayStart) && $iDisplayLength != '-1') {
            $this->db->limit($this->db->escape_str($iDisplayLength), $this->db->escape_str($iDisplayStart));
        }
        
        // Ordering
        if (isset($iSortCol_0)) {
            for ($i=0; $i<intval($iSortingCols); $i++) {
                $iSortCol = $this->input->get_post('iSortCol_'.$i, true);
                $bSortable = $this->input->get_post('bSortable_'.intval($iSortCol), true);
                $sSortDir = $this->input->get_post('sSortDir_'.$i, true);
    
                if ($bSortable == 'true') {
                    $this->db->order_by($aColumns[intval($this->db->escape_str($iSortCol))], $this->db->escape_str($sSortDir));
                }
            }
        }
        
        /* 
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        if (isset($sSearch) && !empty($sSearch)) {
            for ($i=0; $i<count($aColumns); $i++) {
                $bSearchable = $this->input->get_post('bSearchable_'.$i, true);
                
                // Individual column filtering
                if (isset($bSearchable) && $bSearchable == 'true') {
                    $this->db->or_like($aColumns[$i], $this->db->escape_like_str($sSearch));
                }
            }
        }
        
        // Select Data
        $this->db->select('SQL_CALC_FOUND_ROWS '.str_replace(' , ', ' ', implode(', ', $aColumns)), false);
        $rResult = $this->db->get($sTable);
    
        // Data set length after filtering
        $this->db->select('FOUND_ROWS() AS found_rows');
        $iFilteredTotal = $this->db->get()->row()->found_rows;
    
        // Total data set length
        $iTotal = $this->db->count_all($sTable);
    
        // Output
        $output = array(
            'sEcho' => intval($sEcho),
            'iTotalRecords' => $iTotal,
            'iTotalDisplayRecords' => $iFilteredTotal,
            'aaData' => array()
        );
        
		$no = $iDisplayStart;
		
        foreach ($rResult->result_array() as $aRow) {
            $row = array();
			
			$no++;
			$row[] = $no;
			$row[] = $aRow['no_transaksi'];
			$row[] = date_format(new DateTime($aRow['tgl_transaksi']), $this->config->item('FORMAT_DATE_TO_DISPLAY'));
			$row[] = $aRow['no_gr'];
			$row[] = $aRow['supplier_id'];
			$row[] = $aRow['nama_supplier'];
			$row[] = $aRow['no_invoice_supplier'];			
			$row[] = date_format(new DateTime($aRow['tgl_invoice_supplier']), $this->config->item('FORMAT_DATE_TO_DISPLAY'));
			$row[] = date_format(new DateTime($aRow['tgl_jatuh_tempo']), $this->config->item('FORMAT_DATE_TO_DISPLAY'));
			$row[] = $aRow['keterangan'];			
			$row[] = number_format($aRow['grand_total']);
			if ($aRow['validasi'] == '0') {
				$row[] = "<span class='icon-cross2'></span>";	
			} else {
				$row[] = "<span class='icon-check'></span>";
			}
			$row[] = '<a title="Edit Detail" href="pembelian/penerimaan_tagihan/penerimaan_tagihan_detail/?hid='.$aRow['id'].'&sid='.$aRow['supplier_id'].'"><span class="icon-pencil4"></span></a>&nbsp;&nbsp;
					  <a title="Print" href="#"><span class="icon-printer"></span></a>';
			
			$output['aaData'][] = $row;
        }
        echo json_encode($output);
    }
	
	function create_header() {
		$data = array(
			'no_transaksi'          => $this->M_Penerimaan_Tagihan->create_doc_no(date('n'), date('Y')),
			'tgl_transaksi'         => date('Y-m-d'),
			'supplier_id'           => $this->input->post('cbosupplier'),
			'gr_id'          	 	=> $this->input->post('cbonogr'),
			'no_invoice_supplier'    => $this->input->post('txtnoinvoicesupplier'),
			'tgl_invoice_supplier'	=> date_format(new DateTime($this->input->post('txttglinvoicesupplier')), $this->config->item('FORMAT_DATE_TO_INSERT')),
			'tgl_jatuh_tempo'       => date_format(new DateTime($this->input->post('txttgljatuhtempo')),$this->config->item('FORMAT_DATE_TO_INSERT')),
			'keterangan'           	=> $this->input->post('txtketerangan'),
			'created_by'            => $this->session->userdata('user_name'),
			'created_date'          => date('Y-m-d H:i:s'),
			'modified_by'           => $this->session->userdata('user_name'),
			'modified_date'         => date('Y-m-d H:i:s')
		);
		$create_header = $this->M_Penerimaan_Tagihan->header_create($data);
		$hid = $this->session->userdata('hid');
		$sid = $this->input->post('cbosupplier');
		if ($create_header) {
			redirect('pembelian/penerimaan_tagihan/penerimaan_tagihan_detail/?hid='.$hid.'&sid='.$sid);
		} else {
			echo "<script>alert('Fail')</script>";
		}
	}
	
	function penerimaan_tagihan_detail() {
		$hid = $_GET['hid'];
		$sid = $_GET['sid'];
		$this->session->set_userdata('hid', $hid);
				
		$data = array(
			'title' => 'Penerimaan Tagihan',
			'breadcrumb_home_active' => '',
            'breadcrumb' => '<li>Pembelian</li>
                             <li><a href="pembelian/penerimaan_tagihan">Penerimaan Tagihan</a></li>
							 <li>Penerimaan Tagihan Detail</li>',
			'page_icon' => 'icon-new-tab',
			'page_title' => '',
			'page_subtitle' => '',			
			'custom_scripts' => "<script type='text/javascript' src='assets/custom_script/penerimaan_tagihan.js'></script>",
			'get_header' => $this->M_Penerimaan_Tagihan->get_header($hid),
			'get_detail' => $this->M_Penerimaan_Tagihan->get_detail($hid)
		);
		$this->template->build('v_penerimaan_tagihan_detail', $data);		
	}
	
	function produk_per_po() {
		$po_id = $this->input->post('po_id');
		$data = $this->M_Penerimaan_Tagihan->produk_per_po($po_id);
        if ($data->num_rows() > 0) {
			echo "<option value='0' selected>Pilih Produk</option>";
			foreach($data->result() as $r) {
				echo "<option value='$r->produk_id'>".$r->nama_produk."</option>";
			}
        }
	}
    
    function create_detail() {
        $data = array(
            'header_id'             => $this->input->post('header_id'),
            'po_id'                 => $this->input->post('po_id'),
            'produk_id'             => $this->input->post('produk_id'),
            'batch_number'          => $this->input->post('batch_number'),
            'expired_date'          => date_format(new DateTime($this->input->post('expired_date')), $this->config->item('FORMAT_DATE_TO_INSERT')),            
            'jumlah'                => $this->input->post('jumlah'),
            'harga_satuan_beli'     => $this->input->post('harga_satuan'),			
            'total_beli'            => $this->input->post('total_beli'),
            'disc_persen_beli'      => $this->input->post('disc_persen'),
            'disc_rupiah_beli'      => $this->input->post('disc_rp'),
            'netto_beli'            => $this->input->post('netto'),			
            'created_by'            => $this->session->userdata('user_name'),
            'created_date'          => date('Y-m-d H:i:s'),
            'modified_by'           => $this->session->userdata('user_name'),
            'modified_date'         => date('Y-m-d H:i:s')
        );
        $create_detail = $this->M_Penerimaan_Tagihan->detail_create($data);
        if ($create_detail) {
            $set_header = $this->M_Penerimaan_Tagihan->get_total_barang_detail(
                                $this->input->post('header_id'),
                                $this->input->post('disc_persen_hdr'),
                                $this->input->post('disc_rp_hdr'),
                                $this->input->post('ppn_persen_hdr'),
                                $this->input->post('materai')
                          );
            $result = array();
            foreach ($set_header->result_array() as $row) {
                $data['result'] = 'done';
                $data['total_barang'] = $row['total_barang']; 
                $data['disc_persen'] = $row['disc_persen']; 
                $data['disc_rp'] = $row['disc_rupiah']; 
                $data['dpp'] = $row['dpp']; 
                $data['ppn_persen'] = $row['ppn_persen']; 
                $data['ppn_rp'] = $row['ppn_rupiah']; 
                $data['materai'] = $row['materai']; 
                $data['grand_total'] = $row['grand_total_beli'];
            }
            echo json_encode($data);
        } else {
            echo "fail";
		}
	}
	
	function detail_list() {
        $data = $this->M_Penerimaan_Tagihan->detail_list($this->session->userdata('hid'));
        if ($data->num_rows() > 0) {
            $i = 1;
            foreach ($data->result() as $row) {
				echo '<tr>';
				echo    '<td id="id" style="display:none;">'.$row->detail_id.'</td>';
				echo    '<td id="no" style="width: 4%; text-align: center;">'.$i.'</td>';
				echo    '<td id="produk_id" style="display:none;">'.$row->produk_id.'</td>';
				echo    '<td id="nama_produk" style="width: 28%;">'.$row->nama_produk.'</td>';
				echo    '<td id="kemasan_id" style="display:none;">'.$row->kemasan_id.'</td>';
				echo    '<td id="nama_kemasan" style="width: 8%; text-align: center;">'.$row->nama_kemasan.'</td>';
				echo    '<td id="batch_number" style="width: 15%; text-align: center;">'.$row->batch_number.'</td>';
				echo    '<td id="expired_date" style="width: 15%; text-align: right;">'.date_format(new DateTime($row->expired_date), $this->config->item('FORMAT_DATE_TO_DISPLAY')).'</td>';
				echo    '<td id="jumlah" style="text-align: right;">'.number_format($row->jumlah).'</td>';
				echo    '<td id="harga_satuan" style="text-align: right;">'.number_format($row->harga_satuan).'</td>';
				echo    '<td id="total" style="text-align: right;">'.number_format($row->total).'</td>';
				echo    '<td id="disc_persen" style="display:none;">'.number_format($row->disc_persen, 1).'</td>';
				echo    '<td id="disc_rupiah" style="text-align: right;">'.number_format($row->disc_rupiah).'</td>';
				echo    '<td id="netto" style="text-align: right;">'.number_format($row->netto).'</td>';				
				echo 	'<td style="width: 9%; text-align: center;">';
							echo "<span id='edit_detail' title='Edit' class='icon-register' style='cursor: pointer'></span>&nbsp;
								  <span id='hapus_detail' title='Hapus' class='icon-trash2' style='cursor: pointer'></span>";
						
				echo 	'</td>';
				echo '</tr>';
				
				$i++;
            }
        }		
    }
	
	function delete_item_detail() {
        $id = $this->input->post('id');
        $del = $this->M_Penerimaan_Tagihan->delete_item_detail($id);
        if ($del) {
            $set_header = $this->M_Penerimaan_Tagihan->get_total_barang_detail(
                                $this->input->post('header_id'),
                                $this->input->post('disc_persen_hdr'),
                                $this->input->post('disc_rupiah_hdr'),
                                $this->input->post('ppn_persen_hdr'),
                                $this->input->post('materai')
                          );
            $result = array();
            foreach ($set_header->result_array() as $row) {
                $data['result'] = 'done';
                $data['total_barang'] = $row['total_barang']; 
                $data['disc_persen'] = $row['disc_persen']; 
                $data['disc_rupiah'] = $row['disc_rupiah']; 
                $data['dpp'] = $row['dpp']; 
                $data['ppn_persen'] = $row['ppn_persen']; 
                $data['ppn_rupiah'] = $row['ppn_rupiah']; 
                $data['materai'] = $row['materai']; 
                $data['grand_total'] = $row['grand_total'];
            }
            echo json_encode($data);
        } else {
            echo "fail";
		}
    }
    
    function update_item_detail() {		
        $del = $this->M_Penerimaan_Tagihan->update_item_detail();
        if ($del) {
            $set_header = $this->M_Penerimaan_Tagihan->get_total_barang_detail(
                                $this->input->post('header_id'),
                                $this->input->post('disc_persen_hdr'),
                                $this->input->post('disc_rupiah_hdr'),
                                $this->input->post('ppn_persen_hdr'),
                                $this->input->post('materai')
                          );
            $result = array();
            foreach ($set_header->result_array() as $row) {
                $data['result'] = 'done';
                $data['total_barang'] = $row['total_barang']; 
                $data['disc_persen'] = $row['disc_persen']; 
                $data['disc_rupiah'] = $row['disc_rupiah']; 
                $data['dpp'] = $row['dpp']; 
                $data['ppn_persen'] = $row['ppn_persen']; 
                $data['ppn_rupiah'] = $row['ppn_rupiah']; 
                $data['materai'] = $row['materai']; 
                $data['grand_total'] = $row['grand_total'];
            }
            echo json_encode($data);
        } else {
            echo "fail";
		}
    }
	
	function update_header() {		
        $del = $this->M_Penerimaan_Tagihan->update_header();
        if ($del)
            echo "done";
        else
            echo "fail";
    }
	
	function get_gr_supplier() {
		$supplier_id = $this->input->post('supplier_id');
		$data = $this->M_Penerimaan_Tagihan->get_gr($supplier_id);
        if ($data->num_rows() > 0) {
			foreach($data->result() as $r) {
				echo "<option value='$r->gr_id'>".$r->no_gr."</option>";
			}
        }
	}
	
	function get_data_gr() {
		$del = $this->M_Penerimaan_Tagihan->get_data_gr();
        if ($del) {
            $set_header = $this->M_Penerimaan_Tagihan->get_total_barang_detail($this->input->post('hid'));
            $result = array();
            foreach ($set_header->result_array() as $row) {
                $data['result'] = 'done';
                $data['total_barang'] = $row['total_barang']; 
                $data['disc_persen'] = $row['disc_persen']; 
                $data['disc_rupiah'] = $row['disc_rupiah']; 
                $data['dpp'] = $row['dpp']; 
                $data['ppn_persen'] = $row['ppn_persen']; 
                $data['ppn_rupiah'] = $row['ppn_rupiah']; 
                $data['materai'] = $row['materai']; 
                $data['grand_total'] = $row['grand_total'];
            }
            echo json_encode($data);
        } else {
            echo "fail";
		}
	}

} 